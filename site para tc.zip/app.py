from flask import Flask, render_template, request, redirect, url_for, session, jsonify, send_file
import sqlite3
import os
import json
import re
import shutil
import secrets
import unicodedata
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import date, datetime, timedelta
from flask_socketio import SocketIO, emit
from conteudo_pedagogico import PLANOS_LICOES, obter_plano, montar_desafios_teoricos_licao
from backend.desafios_diarios import (
    desafio_por_id as desafio_diario_por_id,
    desafios_disponiveis_por_progresso,
    escolher_desafio_do_dia,
    gerar_desafios_diarios,
)
from backend.progresso_teorico import preparar_desafios_teoricos_view, atualizar_resposta_teorica
from backend import compilador as compilador_seguro
from backend.gamificacao import (
    calendario_atividade,
    estado_nivel,
    liga_por_xp,
    obter_missoes_diarias,
    registrar_atividade,
    resgatar_missao,
    sincronizar_conquistas,
)
import time
import threading
import select

try:
    import pty
except ImportError:
    pty = None

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_hex(32)
app.config.update(
    MAX_CONTENT_LENGTH=256 * 1024,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=bool(os.environ.get("RENDER")),
)

socketio_opcoes = {"async_mode": "threading"}
origens_socket = os.environ.get("SOCKETIO_CORS_ORIGINS", "").strip()
if origens_socket:
    socketio_opcoes["cors_allowed_origins"] = [
        origem.strip() for origem in origens_socket.split(",") if origem.strip()
    ]
socketio = SocketIO(app, **socketio_opcoes)

DB_PATH = os.environ.get("DB_PATH", "instance/ensinar_c.db")


MODULOS = [
    {
        "id": 1,
        "titulo": "Introdução ao C",
        "descricao": "Conheça a linguagem C, sua importância e a estrutura básica de um programa.",
        "icone": "💻",
        "licoes": [
            {
                "id": 1,
                "titulo": "O que é a linguagem C?",
                "conteudo": "A linguagem C é uma linguagem compilada, conhecida por sua eficiência, desempenho e controle de memória.",
                "codigo": '#include <stdio.h>\n\nint main() {\n    printf("Olá, mundo!\\n");\n    return 0;\n}',
                "pergunta": "Qual função inicia a execução de um programa em C?",
                "alternativas": ["printf", "scanf", "main", "include"],
                "resposta": "main",
                "exercicio_codigo": "Faça um programa em C que mostre seu nome na tela usando printf.",
                "codigo_minimo": "#include <stdio.h>\n\nint main() {\n    // escreva seu código aqui\n\n    return 0;\n}"
            },
            {
                "id": 2,
                "titulo": "Estrutura básica",
                "conteudo": "Um programa em C normalmente possui bibliotecas, a função main, comandos dentro de chaves e um retorno ao final.",
                "codigo": '#include <stdio.h>\n\nint main() {\n    printf("Meu primeiro programa em C\\n");\n    return 0;\n}',
                "pergunta": "Qual biblioteca permite usar printf e scanf?",
                "alternativas": ["stdio.h", "math.h", "string.h", "time.h"],
                "resposta": "stdio.h",
                "exercicio_codigo": "Crie um programa que mostre duas mensagens diferentes na tela.",
                "codigo_minimo": "#include <stdio.h>\n\nint main() {\n    // mostre duas mensagens\n\n    return 0;\n}"
            }
        ]
    },
    {
        "id": 2,
        "titulo": "printf e scanf",
        "descricao": "Aprenda a exibir dados na tela e receber entradas do usuário.",
        "icone": "📘",
        "licoes": [
            {
                "id": 3,
                "titulo": "Usando printf",
                "conteudo": "A função printf é utilizada para mostrar mensagens, valores de variáveis e resultados na tela.",
                "codigo": '#include <stdio.h>\n\nint main() {\n    int idade = 18;\n    printf("Idade: %d\\n", idade);\n    return 0;\n}',
                "pergunta": "Qual especificador mostra números inteiros?",
                "alternativas": ["%f", "%c", "%d", "%s"],
                "resposta": "%d",
                "exercicio_codigo": "Faça um programa que declare uma idade e mostre essa idade usando printf.",
                "codigo_minimo": "#include <stdio.h>\n\nint main() {\n    int idade;\n\n    return 0;\n}"
            },
            {
                "id": 4,
                "titulo": "Usando scanf",
                "conteudo": "A função scanf permite ler dados digitados pelo usuário e armazená-los em variáveis.",
                "codigo": '#include <stdio.h>\n\nint main() {\n    int idade;\n    printf("Digite sua idade: ");\n    scanf("%d", &idade);\n    printf("Idade digitada: %d\\n", idade);\n    return 0;\n}',
                "pergunta": "Por que usamos & no scanf?",
                "alternativas": ["Para somar", "Para indicar endereço da variável", "Para imprimir", "Para encerrar"],
                "resposta": "Para indicar endereço da variável",
                "exercicio_codigo": "Faça um programa que leia um número inteiro e mostre esse número na tela.",
                "codigo_minimo": "#include <stdio.h>\n\nint main() {\n    int numero;\n\n    return 0;\n}"
            }
        ]
    },
    {
        "id": 3,
        "titulo": "Variáveis",
        "descricao": "Entenda os principais tipos de dados e como armazenar informações.",
        "icone": "🔢",
        "licoes": [
            {
                "id": 5,
                "titulo": "Tipo int",
                "conteudo": "O tipo int armazena números inteiros, como 1, 10, -5 e 200.",
                "codigo": '#include <stdio.h>\n\nint main() {\n    int numero = 10;\n    printf("%d\\n", numero);\n    return 0;\n}',
                "pergunta": "Qual tipo armazena números inteiros?",
                "alternativas": ["float", "char", "int", "double"],
                "resposta": "int",
                "exercicio_codigo": "Crie duas variáveis inteiras e mostre a soma delas.",
                "codigo_minimo": "#include <stdio.h>\n\nint main() {\n    int a;\n    int b;\n\n    return 0;\n}"
            },
            {
                "id": 6,
                "titulo": "float, double e char",
                "conteudo": "float e double armazenam números com casas decimais. char armazena um caractere.",
                "codigo": '#include <stdio.h>\n\nint main() {\n    float nota = 8.5;\n    char conceito = \'A\';\n    printf("Nota: %.1f - Conceito: %c\\n", nota, conceito);\n    return 0;\n}',
                "pergunta": "Qual tipo armazena um caractere?",
                "alternativas": ["int", "float", "char", "double"],
                "resposta": "char",
                "exercicio_codigo": "Crie uma variável float para uma nota e uma variável char para um conceito. Mostre as duas na tela.",
                "codigo_minimo": "#include <stdio.h>\n\nint main() {\n    float nota;\n    char conceito;\n\n    return 0;\n}"
            }
        ]
    },
    {
        "id": 4,
        "titulo": "Operadores",
        "descricao": "Use operadores aritméticos, relacionais e lógicos.",
        "icone": "➗",
        "licoes": [
            {
                "id": 7,
                "titulo": "Operadores matemáticos",
                "conteudo": "Os operadores matemáticos permitem realizar soma, subtração, multiplicação, divisão e resto.",
                "codigo": '#include <stdio.h>\n\nint main() {\n    int a = 10;\n    int b = 3;\n    printf("Soma: %d\\n", a + b);\n    printf("Multiplicacao: %d\\n", a * b);\n    return 0;\n}',
                "pergunta": "Qual operador realiza multiplicação?",
                "alternativas": ["+", "-", "*", "/"],
                "resposta": "*",
                "exercicio_codigo": "Faça um programa que declare dois números e mostre soma, subtração e multiplicação.",
                "codigo_minimo": "#include <stdio.h>\n\nint main() {\n    int a;\n    int b;\n\n    return 0;\n}"
            }
        ]
    },
    {
        "id": 5,
        "titulo": "Estruturas de Decisão",
        "descricao": "Utilize if, else, else if e switch.",
        "icone": "🔀",
        "licoes": [
            {
                "id": 8,
                "titulo": "if e else",
                "conteudo": "O if executa um bloco se a condição for verdadeira. O else executa outro bloco se for falsa.",
                "codigo": '#include <stdio.h>\n\nint main() {\n    int idade = 18;\n\n    if (idade >= 18) {\n        printf("Maior de idade\\n");\n    } else {\n        printf("Menor de idade\\n");\n    }\n\n    return 0;\n}',
                "pergunta": "Qual comando testa uma condição?",
                "alternativas": ["for", "if", "scanf", "return"],
                "resposta": "if",
                "exercicio_codigo": "Faça um programa que verifique se um número é positivo ou negativo.",
                "codigo_minimo": "#include <stdio.h>\n\nint main() {\n    int numero;\n\n    return 0;\n}"
            }
        ]
    },
    {
        "id": 6,
        "titulo": "Estruturas de Repetição",
        "descricao": "Aprenda while, do while, for, break e continue.",
        "icone": "🔁",
        "licoes": [
            {
                "id": 9,
                "titulo": "Laço for",
                "conteudo": "O for é usado quando sabemos quantas vezes queremos repetir um comando.",
                "codigo": '#include <stdio.h>\n\nint main() {\n    for (int i = 1; i <= 5; i++) {\n        printf("%d\\n", i);\n    }\n    return 0;\n}',
                "pergunta": "Qual estrutura é indicada para repetição com contador?",
                "alternativas": ["if", "else", "for", "switch"],
                "resposta": "for",
                "exercicio_codigo": "Faça um programa que use for para mostrar os números de 1 até 10.",
                "codigo_minimo": "#include <stdio.h>\n\nint main() {\n    // use for aqui\n\n    return 0;\n}"
            }
        ]
    }
]


DESAFIO_DIARIO = {
    "titulo": "Desafio diário: média simples",
    "descricao": "Crie um programa que declare duas notas, calcule a média e mostre o resultado na tela.",
    "codigo_inicial": '#include <stdio.h>\n\nint main() {\n    float nota1 = 8.0;\n    float nota2 = 7.0;\n\n    // calcule a média aqui\n\n    return 0;\n}',
    "dica": "Use uma variável chamada media e faça: media = (nota1 + nota2) / 2;"
}


COMPLEMENTOS_LICOES = {
    1: {"correcao": {"codigo_contem": ["printf"], "saida_obrigatoria": True}},
    2: {"correcao": {"min_ocorrencias_codigo": {"printf": 2}, "min_linhas_saida": 2}},
    3: {"correcao": {"codigo_contem": ["int", "printf"], "saida_regex": [r"\d"]}},
    4: {"correcao": {"codigo_contem": ["scanf", "&", "printf"], "testes": [{"entrada": "42\n", "saida_contem": ["42"]}]}},
    5: {"correcao": {"codigo_contem": ["int", "+", "printf"], "saida_regex": [r"\d"]}},
    6: {"correcao": {"codigo_contem": ["float", "char", "printf"], "saida_obrigatoria": True}},
    7: {"correcao": {"codigo_contem": ["+", "-", "*", "printf"], "min_linhas_saida": 3}},
    8: {"correcao": {"codigo_contem": ["if", "printf"], "saida_regex": [r"positivo|negativo|zero|maior|menor"]}},
    9: {"correcao": {"codigo_contem": ["for", "printf"], "saida_contem": ["1", "10"]}}
}


MODULOS_COMPLEMENTARES = [
    {
        "id": 7,
        "titulo": "Arrays",
        "descricao": "Guarde vários valores em uma mesma estrutura e percorra listas com repetição.",
        "icone": "[]",
        "licoes": [
            {
                "id": 10,
                "titulo": "Vetores",
                "conteudo": "Um vetor armazena vários valores do mesmo tipo. Cada posição é acessada por um índice que começa em zero.",
                "codigo": '#include <stdio.h>\n\nint main() {\n    int valores[5] = {2, 4, 6, 8, 10};\n    printf("%d\\n", valores[2]);\n    return 0;\n}',
                "pergunta": "Qual é o primeiro índice de um vetor em C?",
                "alternativas": ["0", "1", "-1", "10"],
                "resposta": "0",
                "exercicio_codigo": "Crie um vetor com cinco números inteiros e mostre o terceiro valor na tela.",
                "codigo_minimo": "#include <stdio.h>\n\nint main() {\n    int valores[5] = {2, 4, 6, 8, 10};\n\n    return 0;\n}",
                "correcao": {"codigo_contem": ["[", "]", "printf"], "saida_contem": ["6"]}
            },
            {
                "id": 11,
                "titulo": "Percorrendo vetores",
                "conteudo": "Com for, podemos visitar todas as posições de um vetor e acumular resultados.",
                "codigo": '#include <stdio.h>\n\nint main() {\n    int numeros[3] = {1, 2, 3};\n    for (int i = 0; i < 3; i++) {\n        printf("%d\\n", numeros[i]);\n    }\n    return 0;\n}',
                "pergunta": "Qual estrutura combina bem com vetores para percorrer posições?",
                "alternativas": ["for", "return", "include", "char"],
                "resposta": "for",
                "exercicio_codigo": "Some os valores {1, 2, 3, 4, 5} usando um for e mostre o total.",
                "codigo_minimo": "#include <stdio.h>\n\nint main() {\n    int numeros[5] = {1, 2, 3, 4, 5};\n    int soma = 0;\n\n    return 0;\n}",
                "correcao": {"codigo_contem": ["for", "+", "printf"], "saida_contem": ["15"]}
            }
        ]
    },
    {
        "id": 8,
        "titulo": "Strings",
        "descricao": "Trabalhe com textos, vetores de caracteres e funções da biblioteca string.h.",
        "icone": "str",
        "licoes": [
            {
                "id": 12,
                "titulo": "Textos em char[]",
                "conteudo": "Em C, strings são vetores de char terminados pelo caractere nulo, representado por \\0.",
                "codigo": '#include <stdio.h>\n\nint main() {\n    char linguagem[] = "C";\n    printf("Linguagem: %s\\n", linguagem);\n    return 0;\n}',
                "pergunta": "Qual especificador costuma imprimir uma string?",
                "alternativas": ["%s", "%d", "%f", "%c"],
                "resposta": "%s",
                "exercicio_codigo": "Crie uma string com o texto Programar em C e mostre esse texto na tela.",
                "codigo_minimo": "#include <stdio.h>\n\nint main() {\n    char texto[] = \"Programar em C\";\n\n    return 0;\n}",
                "correcao": {"codigo_contem": ["char", "%s", "printf"], "saida_contem": ["programar", "c"]}
            },
            {
                "id": 13,
                "titulo": "strlen",
                "conteudo": "A função strlen, da biblioteca string.h, retorna a quantidade de caracteres de uma string.",
                "codigo": '#include <stdio.h>\n#include <string.h>\n\nint main() {\n    char palavra[] = "codigo";\n    printf("%zu\\n", strlen(palavra));\n    return 0;\n}',
                "pergunta": "Qual biblioteca declara strlen?",
                "alternativas": ["string.h", "stdio.h", "math.h", "stdlib.h"],
                "resposta": "string.h",
                "exercicio_codigo": "Use strlen para mostrar o tamanho da palavra linguagem.",
                "codigo_minimo": "#include <stdio.h>\n#include <string.h>\n\nint main() {\n    char palavra[] = \"linguagem\";\n\n    return 0;\n}",
                "correcao": {"codigo_contem": ["#include <string.h>", "strlen", "printf"], "saida_contem": ["9"]}
            }
        ]
    },
    {
        "id": 9,
        "titulo": "Funções",
        "descricao": "Divida programas em blocos reutilizáveis com parâmetros e retorno.",
        "icone": "fn",
        "licoes": [
            {
                "id": 14,
                "titulo": "Criando funções",
                "conteudo": "Funções evitam repetição e deixam o programa organizado. Elas podem receber valores e devolver um resultado.",
                "codigo": '#include <stdio.h>\n\nint dobro(int n) {\n    return n * 2;\n}\n\nint main() {\n    printf("%d\\n", dobro(5));\n    return 0;\n}',
                "pergunta": "Qual palavra devolve um valor de uma função?",
                "alternativas": ["return", "include", "scanf", "while"],
                "resposta": "return",
                "exercicio_codigo": "Crie uma função quadrado que receba 6 e mostre 36.",
                "codigo_minimo": "#include <stdio.h>\n\nint quadrado(int n) {\n    return 0;\n}\n\nint main() {\n\n    return 0;\n}",
                "correcao": {"codigo_contem": ["quadrado", "return", "*", "printf"], "saida_contem": ["36"]}
            },
            {
                "id": 15,
                "titulo": "Parâmetros e retorno",
                "conteudo": "Parâmetros permitem enviar dados para uma função. O retorno permite usar o resultado em outro ponto do programa.",
                "codigo": '#include <stdio.h>\n\nint maior(int a, int b) {\n    if (a > b) return a;\n    return b;\n}\n\nint main() {\n    printf("%d\\n", maior(7, 12));\n    return 0;\n}',
                "pergunta": "O que os parâmetros fazem?",
                "alternativas": ["Enviam valores para uma função", "Finalizam o programa", "Criam bibliotecas", "Apagam variáveis"],
                "resposta": "Enviam valores para uma função",
                "exercicio_codigo": "Crie uma função maior que receba 7 e 12 e mostre o maior valor.",
                "codigo_minimo": "#include <stdio.h>\n\nint maior(int a, int b) {\n    return 0;\n}\n\nint main() {\n\n    return 0;\n}",
                "correcao": {"codigo_contem": ["maior", "if", "return", "printf"], "saida_contem": ["12"]}
            }
        ]
    },
    {
        "id": 10,
        "titulo": "Ponteiros",
        "descricao": "Entenda endereços de memória, indireção e passagem por referência.",
        "icone": "*",
        "licoes": [
            {
                "id": 16,
                "titulo": "Endereços e valores",
                "conteudo": "Um ponteiro guarda o endereço de uma variável. Com * acessamos o valor apontado e com & pegamos o endereço.",
                "codigo": '#include <stdio.h>\n\nint main() {\n    int valor = 10;\n    int *p = &valor;\n    printf("%d\\n", *p);\n    return 0;\n}',
                "pergunta": "Qual operador obtém o endereço de uma variável?",
                "alternativas": ["&", "*", "%", "#"],
                "resposta": "&",
                "exercicio_codigo": "Crie uma variável valor com 10, um ponteiro para ela e mostre o valor usando o ponteiro.",
                "codigo_minimo": "#include <stdio.h>\n\nint main() {\n    int valor = 10;\n\n    return 0;\n}",
                "correcao": {"codigo_contem": ["*", "&", "printf"], "saida_contem": ["10"]}
            },
            {
                "id": 17,
                "titulo": "Passagem por referência",
                "conteudo": "Ao passar o endereço de uma variável para uma função, a função pode alterar o valor original.",
                "codigo": '#include <stdio.h>\n\nvoid aumentar(int *n) {\n    *n = *n + 1;\n}\n\nint main() {\n    int valor = 5;\n    aumentar(&valor);\n    printf("%d\\n", valor);\n    return 0;\n}',
                "pergunta": "Por que passamos &valor para a função?",
                "alternativas": ["Para enviar o endereço", "Para multiplicar", "Para imprimir texto", "Para encerrar o programa"],
                "resposta": "Para enviar o endereço",
                "exercicio_codigo": "Crie uma função aumentar que receba um ponteiro, some 1 em valor 5 e mostre 6.",
                "codigo_minimo": "#include <stdio.h>\n\nvoid aumentar(int *n) {\n\n}\n\nint main() {\n    int valor = 5;\n\n    return 0;\n}",
                "correcao": {"codigo_contem": ["void aumentar", "*n", "&valor", "printf"], "saida_contem": ["6"]}
            }
        ]
    },
    {
        "id": 11,
        "titulo": "Structs",
        "descricao": "Agrupe dados relacionados em um tipo próprio.",
        "icone": "{}",
        "licoes": [
            {
                "id": 18,
                "titulo": "Criando uma struct",
                "conteudo": "Structs permitem juntar campos diferentes, como nome e nota, em uma única variável.",
                "codigo": '#include <stdio.h>\n\nstruct Aluno {\n    char nome[30];\n    float nota;\n};\n\nint main() {\n    struct Aluno aluno = {"Ana", 9.0};\n    printf("%s %.1f\\n", aluno.nome, aluno.nota);\n    return 0;\n}',
                "pergunta": "Qual palavra cria uma estrutura em C?",
                "alternativas": ["struct", "array", "scanf", "break"],
                "resposta": "struct",
                "exercicio_codigo": "Crie uma struct Aluno com nome Ana e nota 9.0 e mostre os dois valores.",
                "codigo_minimo": "#include <stdio.h>\n\nstruct Aluno {\n\n};\n\nint main() {\n\n    return 0;\n}",
                "correcao": {"codigo_contem": ["struct", "Aluno", "printf"], "saida_contem": ["ana", "9"]}
            },
            {
                "id": 19,
                "titulo": "Vetor de structs",
                "conteudo": "Também é possível criar vetores de structs para guardar vários registros.",
                "codigo": '#include <stdio.h>\n\nstruct Produto {\n    int preco;\n};\n\nint main() {\n    struct Produto produtos[2] = {{10}, {20}};\n    printf("%d\\n", produtos[0].preco + produtos[1].preco);\n    return 0;\n}',
                "pergunta": "Como acessamos um campo de uma struct comum?",
                "alternativas": [".", "->", "&", "#"],
                "resposta": ".",
                "exercicio_codigo": "Crie dois produtos em um vetor de structs, com preços 10 e 20, e mostre a soma 30.",
                "codigo_minimo": "#include <stdio.h>\n\nstruct Produto {\n    int preco;\n};\n\nint main() {\n\n    return 0;\n}",
                "correcao": {"codigo_contem": ["struct", "[", "]", ".preco", "printf"], "saida_contem": ["30"]}
            }
        ]
    },
    {
        "id": 12,
        "titulo": "Arquivos e memória",
        "descricao": "Conheça gravação em arquivo, alocação dinâmica e cuidados comuns.",
        "icone": "io",
        "licoes": [
            {
                "id": 20,
                "titulo": "Escrevendo arquivos",
                "conteudo": "fopen abre um arquivo, fprintf grava dados e fclose fecha o recurso quando terminamos.",
                "codigo": '#include <stdio.h>\n\nint main() {\n    FILE *arquivo = fopen("saida.txt", "w");\n    fprintf(arquivo, "Curso de C");\n    fclose(arquivo);\n    printf("Arquivo gravado\\n");\n    return 0;\n}',
                "pergunta": "Qual função abre um arquivo?",
                "alternativas": ["fopen", "printf", "strlen", "malloc"],
                "resposta": "fopen",
                "exercicio_codigo": "Abra um arquivo, grave uma mensagem, feche o arquivo e mostre Arquivo gravado.",
                "codigo_minimo": "#include <stdio.h>\n\nint main() {\n\n    return 0;\n}",
                "correcao": {"codigo_contem": ["FILE", "fopen", "fprintf", "fclose"], "saida_contem": ["arquivo", "gravado"]}
            },
            {
                "id": 21,
                "titulo": "Alocação dinâmica",
                "conteudo": "malloc reserva memória durante a execução. Depois do uso, free libera essa memória.",
                "codigo": '#include <stdio.h>\n#include <stdlib.h>\n\nint main() {\n    int *numero = malloc(sizeof(int));\n    *numero = 30;\n    printf("%d\\n", *numero);\n    free(numero);\n    return 0;\n}',
                "pergunta": "Qual função libera memória alocada com malloc?",
                "alternativas": ["free", "fclose", "return", "scanf"],
                "resposta": "free",
                "exercicio_codigo": "Use malloc para guardar o número 30, mostre o valor e libere a memória com free.",
                "codigo_minimo": "#include <stdio.h>\n#include <stdlib.h>\n\nint main() {\n\n    return 0;\n}",
                "correcao": {"codigo_contem": ["malloc", "free", "*"], "saida_contem": ["30"]}
            }
        ]
    }
]


def aplicar_conteudo_expandido():
    for modulo in MODULOS:
        for licao in modulo["licoes"]:
            extra = COMPLEMENTOS_LICOES.get(licao["id"])
            if extra:
                licao.update(extra)

    ids_existentes = {modulo["id"] for modulo in MODULOS}
    for modulo in MODULOS_COMPLEMENTARES:
        if modulo["id"] not in ids_existentes:
            MODULOS.append(modulo)


aplicar_conteudo_expandido()


TRILHA_COMPLETA_C = [
    {
        "id": 1,
        "titulo": "Começando a programar",
        "descricao": "Entenda o que é um programa, como o C funciona e quais partes aparecem em um código básico.",
        "icone": "C",
        "conteudos": ["O que é C", "Estrutura básica", "Comentários", "Compilação"],
        "topicos": [
            "linguagem compilada", "sintaxe básica", "estrutura de programas", "eficiência",
            "desempenho", "gerenciamento de memória", "comandos básicos", "bibliotecas",
            "pré-processador", "função main()", "comentários", "compilação e execução",
            "erros de compilação", "mensagens do compilador"
        ]
    },
    {
        "id": 2,
        "titulo": "Conversando com o usuário",
        "descricao": "Aprenda a mostrar mensagens na tela e receber informações digitadas pela pessoa que usa o programa.",
        "icone": "io",
        "conteudos": ["printf", "scanf"],
        "topicos": [
            "saída de dados", "formatação", "%d", "%f", "%c", "%s", "entrada de dados",
            "leitura do teclado", "operador &", "armazenamento de entrada", "validação básica"
        ]
    },
    {
        "id": 3,
        "titulo": "Guardando informações",
        "descricao": "Aprenda a guardar números, letras e valores fixos para usar durante o programa.",
        "icone": "var",
        "conteudos": ["int", "float e double", "char", "constantes", "#define", "escopo"],
        "topicos": [
            "declaração", "inicialização", "memória", "precisão", "ASCII", "constantes",
            "macros", "variáveis locais e globais"
        ]
    },
    {
        "id": 4,
        "titulo": "Fazendo contas e comparações",
        "descricao": "Use o C para somar, subtrair, comparar valores e montar pequenas expressões lógicas.",
        "icone": "+-",
        "conteudos": [
            "soma", "subtração", "multiplicação", "divisão",
            "operadores relacionais", "operadores lógicos", "incremento"
        ],
        "topicos": [
            "operadores matemáticos", "comparação", "expressões booleanas",
            "incremento e decremento", "operações condicionais"
        ]
    },
    {
        "id": 5,
        "titulo": "Tomando decisões",
        "descricao": "Faça o programa escolher caminhos diferentes dependendo de uma condição.",
        "icone": "if",
        "conteudos": ["if", "else", "else if", "switch", "ternário"],
        "topicos": ["condições", "execução condicional", "múltiplas decisões", "switch case", "operador ternário"]
    },
    {
        "id": 6,
        "titulo": "Repetindo tarefas",
        "descricao": "Evite repetir o mesmo código várias vezes usando comandos que executam uma ação em sequência.",
        "icone": "for",
        "conteudos": ["while", "do while", "for", "break", "continue"],
        "topicos": ["loops", "repetição", "controle de execução", "interrupção de laços"]
    },
    {
        "id": 7,
        "titulo": "Organizando o código",
        "descricao": "Divida o programa em partes menores para reutilizar ideias e deixar tudo mais fácil de entender.",
        "icone": "fn",
        "conteudos": ["criando função", "parâmetros", "retorno", "protótipos", "recursão"],
        "topicos": [
            "modularização", "reutilização", "passagem de parâmetros",
            "retorno de valores", "chamadas recursivas"
        ]
    },
    {
        "id": 8,
        "titulo": "Listas e textos",
        "descricao": "Trabalhe com vários valores de uma vez e manipule palavras, nomes e frases.",
        "icone": "[]",
        "conteudos": ["arrays", "matrizes", "strings", "strlen", "strcpy", "strcmp", "strcat", "fgets"],
        "topicos": ["vetores", "matrizes", "manipulação textual", "entrada segura", "funções da biblioteca string"]
    },
    {
        "id": 9,
        "titulo": "Como a memória funciona",
        "descricao": "Entenda como o computador guarda dados e como o C permite acessar esses locais com ponteiros.",
        "icone": "*",
        "conteudos": ["memória", "operador &", "ponteiros + funções", "ponteiros + arrays", "ponteiro para ponteiro"],
        "topicos": ["endereços de memória", "desreferenciamento", "aritmética de ponteiros", "passagem por referência"]
    },
    {
        "id": 10,
        "titulo": "Usando memória quando precisar",
        "descricao": "Aprenda a reservar e liberar memória durante a execução do programa.",
        "icone": "mem",
        "conteudos": ["malloc", "calloc", "realloc", "free", "memory leak"],
        "topicos": ["alocação dinâmica", "heap", "gerenciamento de memória", "vazamento de memória"]
    },
    {
        "id": 11,
        "titulo": "Agrupando informações",
        "descricao": "Crie seus próprios tipos para juntar dados relacionados, como uma ficha de aluno ou produto.",
        "icone": "{}",
        "conteudos": ["structs", "typedef", "unions", "enum"],
        "topicos": ["agrupamento de dados", "tipos personalizados", "compartilhamento de memória", "conjuntos nomeados"]
    },
    {
        "id": 12,
        "titulo": "Salvando dados",
        "descricao": "Grave informações em arquivos e leia esses dados novamente quando precisar.",
        "icone": "file",
        "conteudos": ["fopen", "fclose", "fprintf", "fscanf"],
        "topicos": ["abertura de arquivos", "fechamento de arquivos", "gravação", "leitura formatada"]
    },
    {
        "id": 13,
        "titulo": "Dividindo o programa em partes",
        "descricao": "Separe programas maiores em arquivos diferentes para facilitar organização e manutenção.",
        "icone": ".h",
        "conteudos": [".h", ".c", "include guards"],
        "topicos": ["cabeçalhos", "arquivos fonte", "organização de projetos", "proteção contra inclusão duplicada"]
    },
    {
        "id": 14,
        "titulo": "Usando recursos prontos",
        "descricao": "Conheça bibliotecas que já trazem funções úteis para entrada, texto, memória e matemática.",
        "icone": "lib",
        "conteudos": ["stdio", "stdlib", "string", "math"],
        "topicos": ["entrada e saída", "utilidades gerais", "manipulação de strings", "funções matemáticas"]
    },
    {
        "id": 15,
        "titulo": "Como o computador guarda informações",
        "descricao": "Veja como dados podem ser manipulados em zeros e uns usando operações de baixo nível.",
        "icone": "01",
        "conteudos": ["bitwise", "máscaras"],
        "topicos": ["operações bit a bit", "AND", "OR", "XOR", "deslocamento", "máscaras de bits"]
    },
    {
        "id": 16,
        "titulo": "Encontrando e corrigindo erros",
        "descricao": "Aprenda a identificar mensagens do compilador, erros de lógica e formas de investigar problemas.",
        "icone": "bug",
        "conteudos": ["erros de sintaxe", "erros lógicos", "debug"],
        "topicos": ["mensagens de erro", "teste de hipóteses", "rastreamento de valores", "correção de falhas"]
    },
    {
        "id": 17,
        "titulo": "Transformando código em programa",
        "descricao": "Entenda como o compilador transforma arquivos de código em um programa executável.",
        "icone": "gcc",
        "conteudos": ["gcc", "linking", "makefile"],
        "topicos": ["compilador GCC", "etapas de build", "ligação de objetos", "automação de compilação"]
    },
    {
        "id": 18,
        "titulo": "Escrevendo programas seguros",
        "descricao": "Aprenda cuidados para evitar falhas comuns, entradas inválidas e problemas com memória.",
        "icone": "sec",
        "conteudos": ["buffer overflow", "validação"],
        "topicos": ["limites de buffers", "entrada insegura", "validação de dados", "boas práticas"]
    },
    {
        "id": 19,
        "titulo": "Organizando muitos dados",
        "descricao": "Use listas, pilhas, filas e árvores para organizar informações de formas diferentes.",
        "icone": "ds",
        "conteudos": ["listas", "pilhas", "filas", "árvores"],
        "topicos": ["organização de dados", "inserção", "remoção", "percurso", "uso de ponteiros"]
    },
    {
        "id": 20,
        "titulo": "Resolvendo problemas melhor",
        "descricao": "Aprenda formas de procurar, ordenar e comparar soluções para resolver problemas com mais eficiência.",
        "icone": "alg",
        "conteudos": ["busca linear", "bubble sort", "eficiência"],
        "topicos": ["busca sequencial", "ordenação simples", "complexidade", "comparação de desempenho"]
    },
    {
        "id": 21,
        "titulo": "Criando programas completos",
        "descricao": "Junte o que foi aprendido para criar projetos maiores do começo ao fim.",
        "icone": "app",
        "conteudos": [
            "calculadora", "cadastro", "agenda", "jogo terminal",
            "sistema biblioteca", "editor texto", "projeto final"
        ],
        "topicos": ["integração de conteúdos", "organização", "entrada e saída", "persistência", "projeto completo"]
    }
]


AJUSTES_DIDATICOS_LICOES = {
    "O que é C": {
        "pratica_codigo": False,
        "exercicio_codigo": "Esta lição é apenas para entender a ideia geral da linguagem C. Responda o desafio teórico para avançar."
    },
    "Estrutura básica": {
        "pratica_codigo": False,
        "exercicio_codigo": "Nesta etapa, observe a estrutura de um programa pronto. A prática de escrita começa depois que a saída de dados for ensinada."
    },
    "Comentários": {
        "pratica_codigo": False,
        "exercicio_codigo": "Comentários servem para leitura do código. Por enquanto, responda o desafio teórico e avance."
    },
    "Compilação": {
        "pratica_codigo": False,
        "exercicio_codigo": "Esta lição explica o caminho do código até virar programa. A prática de compilação aparece novamente mais adiante."
    },
    "printf": {
        "codigo": '#include <stdio.h>\n\nint main(void) {\n    printf("Ola, estudante!\\n");\n    printf("Estou aprendendo C.\\n");\n    return 0;\n}',
        "exercicio_codigo": 'Mostre exatamente a mensagem "Ola, C" usando printf.',
        "codigo_minimo": '#include <stdio.h>\n\nint main(void) {\n    /* Use printf para mostrar a mensagem pedida. */\n    return 0;\n}',
        "correcao": {"codigo_contem": ["printf"], "saida_contem": ["Ola, C"]}
    },
    "scanf": {
        "codigo": '#include <stdio.h>\n\nint main(void) {\n    int numero;\n    printf("Digite um numero: ");\n    scanf("%d", &numero);\n    printf("Numero: %d\\n", numero);\n    return 0;\n}',
        "exercicio_codigo": 'Leia um número inteiro digitado pelo usuário e mostre no formato "Numero: N".',
        "codigo_minimo": '#include <stdio.h>\n\nint main(void) {\n    int numero;\n    /* Use scanf e depois mostre o valor lido. */\n    return 0;\n}',
        "correcao": {"codigo_contem": ["scanf", "&numero", "printf"], "testes": [{"entrada": "42\n", "saida_contem": ["Numero: 42"]}]}
    },
    "int": {
        "codigo": '#include <stdio.h>\n\nint main(void) {\n    int idade = 18;\n    printf("Idade: %d\\n", idade);\n    return 0;\n}',
        "exercicio_codigo": 'Crie uma variável int chamada idade com valor 20 e mostre "Idade: 20".',
        "codigo_minimo": '#include <stdio.h>\n\nint main(void) {\n    /* Declare a variável idade aqui. */\n    return 0;\n}',
        "correcao": {"codigo_contem": ["int", "idade", "printf"], "saida_contem": ["Idade: 20"]}
    },
    "float e double": {
        "codigo": '#include <stdio.h>\n\nint main(void) {\n    double nota = 8.5;\n    printf("Nota: %.1f\\n", nota);\n    return 0;\n}',
        "exercicio_codigo": 'Crie uma variável double chamada nota com valor 9.5 e mostre "Nota: 9.5".',
        "codigo_minimo": '#include <stdio.h>\n\nint main(void) {\n    /* Declare a variável nota aqui. */\n    return 0;\n}',
        "correcao": {"codigo_contem": ["double", "nota", "printf"], "saida_contem": ["Nota: 9.5"]}
    },
    "char": {
        "codigo": '#include <stdio.h>\n\nint main(void) {\n    char inicial = \'C\';\n    printf("Inicial: %c\\n", inicial);\n    return 0;\n}',
        "exercicio_codigo": 'Crie uma variável char chamada letra com valor C e mostre "Letra: C".',
        "codigo_minimo": '#include <stdio.h>\n\nint main(void) {\n    /* Declare a variável letra aqui. */\n    return 0;\n}',
        "correcao": {"codigo_contem": ["char", "letra", "'C'", "printf"], "saida_contem": ["Letra: C"]}
    },
    "constantes": {
        "codigo": '#include <stdio.h>\n\nint main(void) {\n    const int LIMITE = 100;\n    printf("Limite: %d\\n", LIMITE);\n    return 0;\n}',
        "exercicio_codigo": 'Crie uma constante int chamada ANO com valor 2026 e mostre "Ano: 2026".',
        "codigo_minimo": '#include <stdio.h>\n\nint main(void) {\n    /* Declare a constante ANO aqui. */\n    return 0;\n}',
        "correcao": {"codigo_contem": ["const int", "ANO", "printf"], "saida_contem": ["Ano: 2026"]}
    },
    "#define": {
        "codigo": '#include <stdio.h>\n\n#define CURSO "C"\n\nint main(void) {\n    printf("Curso: %s\\n", CURSO);\n    return 0;\n}',
        "exercicio_codigo": 'Crie um #define chamado ESCOLA com o texto "Ensinar C" e mostre esse texto.',
        "codigo_minimo": '#include <stdio.h>\n\n/* Crie o #define aqui. */\n\nint main(void) {\n    return 0;\n}',
        "correcao": {"codigo_contem": ["#define", "ESCOLA", "printf"], "saida_contem": ["Ensinar C"]}
    },
    "escopo": {
        "codigo": '#include <stdio.h>\n\nint main(void) {\n    int fora = 10;\n    {\n        int dentro = 20;\n        printf("Dentro: %d\\n", dentro);\n    }\n    printf("Fora: %d\\n", fora);\n    return 0;\n}',
        "exercicio_codigo": 'Crie uma variável local chamada valor dentro da função main e mostre "Valor: 30".',
        "codigo_minimo": '#include <stdio.h>\n\nint main(void) {\n    /* Crie a variável valor aqui. */\n    return 0;\n}',
        "correcao": {"codigo_contem": ["int valor", "printf"], "saida_contem": ["Valor: 30"]}
    },
    "divisão": {
        "codigo": '#include <stdio.h>\n\nint main(void) {\n    double resultado = 7.0 / 2.0;\n    printf("Resultado: %.2f\\n", resultado);\n    return 0;\n}',
        "exercicio_codigo": 'Divida 10.0 por 4.0 e mostre o resultado com duas casas decimais.',
        "codigo_minimo": '#include <stdio.h>\n\nint main(void) {\n    /* Calcule a divisão aqui. */\n    return 0;\n}',
        "correcao": {"codigo_contem": ["/", "%.2f", "printf"], "saida_contem": ["2.50"]}
    },
    "operadores lógicos": {
        "codigo": '#include <stdio.h>\n\nint main(void) {\n    int resultado = (10 > 5) && (3 < 8);\n    printf("Resultado: %d\\n", resultado);\n    return 0;\n}',
        "exercicio_codigo": 'Use && em uma expressão verdadeira e mostre "Resultado: 1".',
        "codigo_minimo": '#include <stdio.h>\n\nint main(void) {\n    /* Crie a expressão lógica aqui. */\n    return 0;\n}',
        "correcao": {"codigo_contem": ["&&", "printf"], "saida_contem": ["Resultado: 1"]}
    }
}


def codigo_exemplo_para_conteudo(conteudo):
    chave = conteudo.lower()

    exemplos_diretos = {
        "o que é c": '#include <stdio.h>\n\nint main(void) {\n    printf("C transforma codigo-fonte em programas eficientes.\\n");\n    return 0;\n}',
        "estrutura básica": '#include <stdio.h>\n\nint main(void) {\n    int resposta = 42;\n    printf("Resposta: %d\\n", resposta);\n    return 0;\n}',
        "comentários": '#include <stdio.h>\n\nint main(void) {\n    // Comentario de uma linha\n    /* Comentario de bloco: explica a intencao. */\n    printf("Comentarios nao sao executados.\\n");\n    return 0;\n}',
        "compilação": '#include <stdio.h>\n\nint main(void) {\n    int resultado = 6 * 7;\n    printf("Resultado compilado: %d\\n", resultado);\n    return 0;\n}',
        "printf": '#include <stdio.h>\n\nint main(void) {\n    int quantidade = 3;\n    double preco = 12.50;\n    char categoria = \'A\';\n    printf("%d itens | R$ %.2f | categoria %c\\n", quantidade, preco, categoria);\n    return 0;\n}',
        "int": '#include <stdio.h>\n\nint main(void) {\n    int caixas = 6;\n    int itensPorCaixa = 7;\n    printf("Total: %d\\n", caixas * itensPorCaixa);\n    return 0;\n}',
        "float e double": '#include <stdio.h>\n\nint main(void) {\n    float nota = 8.5f;\n    double media = (nota + 9.5) / 2.0;\n    printf("Media: %.2f\\n", media);\n    return 0;\n}',
        "char": '#include <stdio.h>\n\nint main(void) {\n    char letra = \'C\';\n    printf("Caractere: %c | codigo: %d\\n", letra, letra);\n    return 0;\n}',
        "constantes": '#include <stdio.h>\n\nint main(void) {\n    const int DIAS_SEMANA = 7;\n    printf("Tres semanas: %d dias\\n", DIAS_SEMANA * 3);\n    return 0;\n}',
        "#define": '#include <stdio.h>\n\n#define QUADRADO(x) ((x) * (x))\n\nint main(void) {\n    printf("Quadrado: %d\\n", QUADRADO(6));\n    return 0;\n}',
        "escopo": '#include <stdio.h>\n\nconst int LIMITE = 100;\n\nint main(void) {\n    int valor = 42;\n    if (valor < LIMITE) {\n        int diferenca = LIMITE - valor;\n        printf("Faltam %d\\n", diferenca);\n    }\n    return 0;\n}',
        "soma": '#include <stdio.h>\n\nint main(void) {\n    int a = 19;\n    int b = 23;\n    printf("Soma: %d\\n", a + b);\n    return 0;\n}',
        "subtração": '#include <stdio.h>\n\nint main(void) {\n    int saldo = 100;\n    int retirada = 58;\n    printf("Saldo: %d\\n", saldo - retirada);\n    return 0;\n}',
        "multiplicação": '#include <stdio.h>\n\nint main(void) {\n    int linhas = 6;\n    int colunas = 7;\n    printf("Celulas: %d\\n", linhas * colunas);\n    return 0;\n}',
        "divisão": '#include <stdio.h>\n\nint main(void) {\n    int total = 7;\n    int pessoas = 2;\n    printf("Divisao inteira: %d\\n", total / pessoas);\n    printf("Divisao real: %.2f\\n", (double) total / pessoas);\n    return 0;\n}',
        "operadores relacionais": '#include <stdio.h>\n\nint main(void) {\n    int a = 42;\n    int b = 20;\n    printf("a > b: %d | a == b: %d\\n", a > b, a == b);\n    return 0;\n}',
        "operadores lógicos": '#include <stdio.h>\n\nint main(void) {\n    int idade = 20;\n    int temDocumento = 1;\n    if (idade >= 18 && temDocumento) {\n        printf("Entrada permitida\\n");\n    }\n    return 0;\n}',
        "incremento": '#include <stdio.h>\n\nint main(void) {\n    int contador = 40;\n    contador++;\n    ++contador;\n    printf("%d\\n", contador);\n    return 0;\n}',
        "else if": '#include <stdio.h>\n\nint main(void) {\n    int nota = 8;\n    if (nota >= 9) {\n        printf("Conceito A\\n");\n    } else if (nota >= 7) {\n        printf("Conceito B\\n");\n    } else {\n        printf("Conceito C\\n");\n    }\n    return 0;\n}',
        "ternário": '#include <stdio.h>\n\nint main(void) {\n    int a = 17, b = 42;\n    int maior = a > b ? a : b;\n    printf("Maior: %d\\n", maior);\n    return 0;\n}',
        "break": '#include <stdio.h>\n\nint main(void) {\n    for (int i = 1; i <= 10; i++) {\n        if (i == 6) break;\n        printf("%d ", i);\n    }\n    printf("\\n");\n    return 0;\n}',
        "continue": '#include <stdio.h>\n\nint main(void) {\n    for (int i = 1; i <= 6; i++) {\n        if (i % 2 == 0) continue;\n        printf("%d ", i);\n    }\n    printf("\\n");\n    return 0;\n}',
        "matrizes": '#include <stdio.h>\n\nint main(void) {\n    int matriz[2][2] = {{10, 2}, {3, 32}};\n    int diagonal = 0;\n    for (int i = 0; i < 2; i++) diagonal += matriz[i][i];\n    printf("Diagonal: %d\\n", diagonal);\n    return 0;\n}',
        "strings": '#include <stdio.h>\n\nint main(void) {\n    char texto[] = "Linguagem C";\n    for (int i = 0; texto[i] != \'\\0\'; i++) putchar(texto[i]);\n    putchar(\'\\n\');\n    return 0;\n}',
        "strlen": '#include <stdio.h>\n#include <string.h>\n\nint main(void) {\n    const char palavra[] = "compilar";\n    printf("Tamanho: %zu\\n", strlen(palavra));\n    return 0;\n}',
        "strcpy": '#include <stdio.h>\n#include <string.h>\n\nint main(void) {\n    char destino[20];\n    strcpy(destino, "C seguro");\n    printf("%s\\n", destino);\n    return 0;\n}',
        "strcmp": '#include <stdio.h>\n#include <string.h>\n\nint main(void) {\n    const char a[] = "casa";\n    const char b[] = "casa";\n    if (strcmp(a, b) == 0) printf("Iguais\\n");\n    return 0;\n}',
        "strcat": '#include <stdio.h>\n#include <string.h>\n\nint main(void) {\n    char destino[30] = "Curso ";\n    strcat(destino, "de C");\n    printf("%s\\n", destino);\n    return 0;\n}',
        "fgets": '#include <stdio.h>\n#include <string.h>\n\nint main(void) {\n    char nome[40];\n    printf("Nome: ");\n    if (fgets(nome, sizeof(nome), stdin) != NULL) {\n        nome[strcspn(nome, "\\n")] = \'\\0\';\n        printf("Ola, %s\\n", nome);\n    }\n    return 0;\n}',
        "operador &": '#include <stdio.h>\n\nint main(void) {\n    int valor = 42;\n    int *ponteiro = &valor;\n    printf("Valor: %d\\n", *ponteiro);\n    return 0;\n}',
        "ponteiros + funções": '#include <stdio.h>\n\nvoid trocar(int *a, int *b) {\n    int temporario = *a;\n    *a = *b;\n    *b = temporario;\n}\n\nint main(void) {\n    int a = 10, b = 42;\n    trocar(&a, &b);\n    printf("%d %d\\n", a, b);\n    return 0;\n}',
        "ponteiros + arrays": '#include <stdio.h>\n\nint main(void) {\n    int valores[] = {10, 20, 12};\n    int *p = valores;\n    int total = 0;\n    for (int i = 0; i < 3; i++) total += *(p + i);\n    printf("%d\\n", total);\n    return 0;\n}',
        "ponteiro para ponteiro": '#include <stdio.h>\n\nint main(void) {\n    int valor = 10;\n    int *p = &valor;\n    int **pp = &p;\n    **pp = 42;\n    printf("%d\\n", valor);\n    return 0;\n}',
        "calloc": '#include <stdio.h>\n#include <stdlib.h>\n\nint main(void) {\n    int *valores = calloc(4, sizeof(*valores));\n    if (valores == NULL) return 1;\n    valores[3] = 42;\n    for (int i = 0; i < 4; i++) printf("%d ", valores[i]);\n    printf("\\n");\n    free(valores);\n    return 0;\n}',
        "realloc": '#include <stdio.h>\n#include <stdlib.h>\n\nint main(void) {\n    int *valores = malloc(2 * sizeof(*valores));\n    if (valores == NULL) return 1;\n    int *temporario = realloc(valores, 3 * sizeof(*valores));\n    if (temporario == NULL) {\n        free(valores);\n        return 1;\n    }\n    valores = temporario;\n    valores[0] = 10; valores[1] = 20; valores[2] = 12;\n    printf("%d\\n", valores[0] + valores[1] + valores[2]);\n    free(valores);\n    return 0;\n}',
        "free": '#include <stdio.h>\n#include <stdlib.h>\n\nint main(void) {\n    int *valor = malloc(sizeof(*valor));\n    if (valor == NULL) return 1;\n    *valor = 42;\n    printf("%d\\n", *valor);\n    free(valor);\n    valor = NULL;\n    return 0;\n}',
        "memory leak": '#include <stdio.h>\n#include <stdlib.h>\n\nstatic int executar(void) {\n    int *valor = malloc(sizeof(*valor));\n    if (valor == NULL) return 0;\n    *valor = 42;\n    int resultado = *valor;\n    free(valor);\n    return resultado;\n}\n\nint main(void) {\n    printf("%d\\n", executar());\n    return 0;\n}',
        "fopen": '#include <stdio.h>\n\nint main(void) {\n    FILE *arquivo = fopen("dados.txt", "w");\n    if (arquivo == NULL) return 1;\n    printf("Arquivo aberto\\n");\n    fclose(arquivo);\n    return 0;\n}',
        "fclose": '#include <stdio.h>\n\nint main(void) {\n    FILE *arquivo = fopen("dados.txt", "w");\n    if (arquivo == NULL) return 1;\n    fprintf(arquivo, "%d\\n", 42);\n    if (fclose(arquivo) == 0) printf("Arquivo fechado\\n");\n    return 0;\n}',
        "fprintf": '#include <stdio.h>\n\nint main(void) {\n    FILE *arquivo = fopen("resultado.txt", "w");\n    if (arquivo == NULL) return 1;\n    fprintf(arquivo, "Resposta: %d\\n", 42);\n    fclose(arquivo);\n    printf("Gravado\\n");\n    return 0;\n}',
        "fscanf": '#include <stdio.h>\n\nint main(void) {\n    FILE *arquivo = fopen("numeros.txt", "w");\n    if (arquivo == NULL) return 1;\n    fprintf(arquivo, "19 23\\n");\n    fclose(arquivo);\n    arquivo = fopen("numeros.txt", "r");\n    if (arquivo == NULL) return 1;\n    int a, b;\n    if (fscanf(arquivo, "%d %d", &a, &b) == 2) printf("%d\\n", a + b);\n    fclose(arquivo);\n    return 0;\n}',
        ".h": '#include <stdio.h>\n\nint dobro(int valor);\n\nint main(void) {\n    printf("%d\\n", dobro(21));\n    return 0;\n}\n\nint dobro(int valor) {\n    return valor * 2;\n}',
        ".c": '#include <stdio.h>\n\nint triplo(int valor);\n\nint main(void) {\n    printf("%d\\n", triplo(14));\n    return 0;\n}\n\nint triplo(int valor) {\n    return valor * 3;\n}',
        "include guards": '#include <stdio.h>\n\n#ifndef MATEMATICA_H\n#define MATEMATICA_H\nint dobro(int valor);\n#endif\n\nint dobro(int valor) {\n    return valor * 2;\n}\n\nint main(void) {\n    printf("%d\\n", dobro(21));\n    return 0;\n}',
        "stdio": '#include <stdio.h>\n\nint main(void) {\n    fprintf(stdout, "Saida padrao: %d\\n", 42);\n    return 0;\n}',
        "stdlib": '#include <stdio.h>\n#include <stdlib.h>\n\nint main(void) {\n    char texto[] = "42";\n    char *fim;\n    long valor = strtol(texto, &fim, 10);\n    if (*fim == \'\\0\') printf("%ld\\n", valor);\n    return 0;\n}',
        "string": '#include <stdio.h>\n#include <string.h>\n\nint main(void) {\n    char texto[10];\n    strcpy(texto, "C");\n    strcat(texto, "11");\n    printf("%s: %s\\n", texto, strcmp(texto, "C11") == 0 ? "correto" : "erro");\n    return 0;\n}',
        "bitwise": '#include <stdio.h>\n\nint main(void) {\n    unsigned valor = 21u;\n    printf("%u\\n", valor << 1);\n    return 0;\n}',
        "máscaras": '#include <stdio.h>\n\n#define LER (1u << 0)\n#define ESCREVER (1u << 1)\n#define EXECUTAR (1u << 2)\n\nint main(void) {\n    unsigned permissoes = LER | EXECUTAR;\n    if ((permissoes & EXECUTAR) != 0u) printf("Pode executar\\n");\n    return 0;\n}',
        "erros de sintaxe": '#include <stdio.h>\n\nint main(void) {\n    int resposta = 42;\n    printf("%d\\n", resposta);\n    return 0;\n}',
        "erros lógicos": '#include <stdio.h>\n\nint main(void) {\n    double media = (8.0 + 10.0 + 12.0) / 3.0;\n    printf("%.2f\\n", media);\n    return 0;\n}',
        "debug": '#include <stdio.h>\n\nint main(void) {\n    int valores[] = {10, 20, 12};\n    int total = 0;\n    for (int i = 0; i < 3; i++) {\n        total += valores[i];\n        printf("i=%d total=%d\\n", i, total);\n    }\n    return 0;\n}',
        "gcc": '#include <stdio.h>\n\nint main(void) {\n    printf("Programa C11 compilado com avisos habilitados.\\n");\n    return 0;\n}',
        "linking": '#include <stdio.h>\n\nint resposta(void);\n\nint main(void) {\n    printf("%d\\n", resposta());\n    return 0;\n}\n\nint resposta(void) {\n    return 42;\n}',
        "makefile": '#include <stdio.h>\n\nint main(void) {\n    const char *comando = "gcc -std=c11 -Wall main.c -o programa";\n    printf("%s\\n", comando);\n    return 0;\n}',
        "buffer overflow": '#include <stdio.h>\n\nint main(void) {\n    char nome[10];\n    printf("Uma palavra: ");\n    if (scanf("%9s", nome) == 1) {\n        printf("Recebido: %s\\n", nome);\n    }\n    return 0;\n}',
        "listas": '#include <stdio.h>\n\nstruct No {\n    int valor;\n    struct No *proximo;\n};\n\nint main(void) {\n    struct No terceiro = {12, NULL};\n    struct No segundo = {20, &terceiro};\n    struct No primeiro = {10, &segundo};\n    int total = 0;\n    for (struct No *p = &primeiro; p != NULL; p = p->proximo) total += p->valor;\n    printf("%d\\n", total);\n    return 0;\n}',
        "pilhas": '#include <stdio.h>\n\nint main(void) {\n    int pilha[3];\n    int topo = 0;\n    pilha[topo++] = 10;\n    pilha[topo++] = 42;\n    printf("Pop: %d\\n", pilha[--topo]);\n    return 0;\n}',
        "filas": '#include <stdio.h>\n\nint main(void) {\n    int fila[3];\n    int inicio = 0, fim = 0;\n    fila[fim++] = 42;\n    fila[fim++] = 10;\n    printf("Primeiro: %d\\n", fila[inicio++]);\n    return 0;\n}',
        "árvores": '#include <stdio.h>\n\nstruct No {\n    int valor;\n    struct No *esquerda;\n    struct No *direita;\n};\n\nvoid emOrdem(struct No *no) {\n    if (no == NULL) return;\n    emOrdem(no->esquerda);\n    printf("%d ", no->valor);\n    emOrdem(no->direita);\n}\n\nint main(void) {\n    struct No esq = {10, NULL, NULL};\n    struct No dir = {42, NULL, NULL};\n    struct No raiz = {20, &esq, &dir};\n    emOrdem(&raiz);\n    printf("\\n");\n    return 0;\n}',
        "eficiência": '#include <stdio.h>\n\nint main(void) {\n    int valores[] = {2, 5, 8, 11, 42};\n    int pares = 0;\n    for (int i = 0; i < 5; i++) if (valores[i] % 2 == 0) pares++;\n    printf("Pares: %d\\n", pares);\n    return 0;\n}',
        "calculadora": '#include <stdio.h>\n\nint main(void) {\n    double a = 20.0, b = 22.0;\n    char operador = \'+\';\n    if (operador == \'+\') printf("Resultado: %.2f\\n", a + b);\n    return 0;\n}',
        "cadastro": '#include <stdio.h>\n\nstruct Pessoa { char nome[30]; int idade; };\n\nint main(void) {\n    struct Pessoa pessoa = {"Ana", 42};\n    printf("%s tem %d anos\\n", pessoa.nome, pessoa.idade);\n    return 0;\n}',
        "agenda": '#include <stdio.h>\n#include <string.h>\n\nstruct Contato { char nome[30]; char telefone[20]; };\n\nint main(void) {\n    struct Contato contato = {"Ana", "4242-4242"};\n    if (strcmp(contato.nome, "Ana") == 0) printf("%s\\n", contato.telefone);\n    return 0;\n}',
        "jogo terminal": '#include <stdio.h>\n\nint main(void) {\n    int alvo = 42;\n    int tentativa = 42;\n    if (tentativa == alvo) printf("Acertou\\n");\n    return 0;\n}',
        "sistema biblioteca": '#include <stdio.h>\n\nstruct Livro { char titulo[30]; int disponivel; };\n\nint main(void) {\n    struct Livro livro = {"C na pratica", 1};\n    if (livro.disponivel) {\n        livro.disponivel = 0;\n        printf("Emprestado\\n");\n    }\n    return 0;\n}',
        "editor texto": '#include <stdio.h>\n#include <string.h>\n\nint main(void) {\n    char texto[50] = "Aprender ";\n    if (strlen(texto) + strlen("C") + 1 <= sizeof(texto)) strcat(texto, "C");\n    printf("%s\\n", texto);\n    return 0;\n}',
        "projeto final": '#include <stdio.h>\n\nstatic double media(double a, double b, double c) {\n    return (a + b + c) / 3.0;\n}\n\nint main(void) {\n    printf("Media: %.2f\\n", media(7.0, 8.0, 9.0));\n    return 0;\n}',
    }

    if chave in exemplos_diretos:
        return exemplos_diretos[chave]

    if "scanf" in chave or "entrada" in chave or "validação" in chave:
        return '#include <stdio.h>\n\nint main() {\n    int numero;\n    printf("Digite um numero: ");\n    scanf("%d", &numero);\n    printf("Valor informado: %d\\n", numero);\n    return 0;\n}'
    if "if" in chave or "else" in chave or "ternário" in chave:
        return '#include <stdio.h>\n\nint main() {\n    int idade = 18;\n    if (idade >= 18) {\n        printf("Maior de idade\\n");\n    } else {\n        printf("Menor de idade\\n");\n    }\n    return 0;\n}'
    if "switch" in chave:
        return '#include <stdio.h>\n\nint main() {\n    int opcao = 2;\n    switch (opcao) {\n        case 1: printf("Cadastrar\\n"); break;\n        case 2: printf("Consultar\\n"); break;\n        default: printf("Opcao invalida\\n");\n    }\n    return 0;\n}'
    if "do while" in chave:
        return '#include <stdio.h>\n\nint main(void) {\n    int contador = 1;\n    do {\n        printf("%d\\n", contador);\n        contador++;\n    } while (contador <= 3);\n    return 0;\n}'
    if "while" in chave:
        return '#include <stdio.h>\n\nint main(void) {\n    int contador = 1;\n    while (contador <= 3) {\n        printf("%d\\n", contador);\n        contador++;\n    }\n    return 0;\n}'
    if "for" in chave or "break" in chave or "continue" in chave:
        return '#include <stdio.h>\n\nint main() {\n    for (int i = 1; i <= 5; i++) {\n        if (i == 3) continue;\n        printf("%d\\n", i);\n    }\n    return 0;\n}'
    if "função" in chave or "parâmetro" in chave or "retorno" in chave or "protótipo" in chave:
        return '#include <stdio.h>\n\nint dobro(int n) {\n    return n * 2;\n}\n\nint main() {\n    printf("%d\\n", dobro(5));\n    return 0;\n}'
    if "recurs" in chave:
        return '#include <stdio.h>\n\nint fatorial(int n) {\n    if (n <= 1) return 1;\n    return n * fatorial(n - 1);\n}\n\nint main() {\n    printf("%d\\n", fatorial(5));\n    return 0;\n}'
    if "array" in chave or "vetor" in chave or "matriz" in chave:
        return '#include <stdio.h>\n\nint main() {\n    int valores[3] = {10, 20, 30};\n    for (int i = 0; i < 3; i++) {\n        printf("%d\\n", valores[i]);\n    }\n    return 0;\n}'
    if "string" in chave or "strlen" in chave or "strcpy" in chave or "strcmp" in chave or "strcat" in chave or "fgets" in chave:
        return '#include <stdio.h>\n#include <string.h>\n\nint main() {\n    char palavra[] = "codigo";\n    printf("Tamanho: %zu\\n", strlen(palavra));\n    return 0;\n}'
    if "ponteiro" in chave or "memória" in chave or "operador &" in chave:
        return '#include <stdio.h>\n\nint main() {\n    int valor = 10;\n    int *p = &valor;\n    printf("%d\\n", *p);\n    return 0;\n}'
    if "malloc" in chave or "calloc" in chave or "realloc" in chave or "free" in chave or "memory leak" in chave:
        return '#include <stdio.h>\n#include <stdlib.h>\n\nint main() {\n    int *numero = malloc(sizeof(int));\n    *numero = 30;\n    printf("%d\\n", *numero);\n    free(numero);\n    return 0;\n}'
    if "struct" in chave or "typedef" in chave:
        return '#include <stdio.h>\n\ntypedef struct {\n    char nome[30];\n    int idade;\n} Pessoa;\n\nint main() {\n    Pessoa pessoa = {"Ana", 20};\n    printf("%s %d\\n", pessoa.nome, pessoa.idade);\n    return 0;\n}'
    if "union" in chave:
        return '#include <stdio.h>\n\nunion Valor {\n    int inteiro;\n    float decimal;\n};\n\nint main() {\n    union Valor v;\n    v.inteiro = 10;\n    printf("%d\\n", v.inteiro);\n    return 0;\n}'
    if "enum" in chave:
        return '#include <stdio.h>\n\nenum Status {ABERTO, FECHADO};\n\nint main() {\n    enum Status atual = ABERTO;\n    printf("%d\\n", atual);\n    return 0;\n}'
    if "fopen" in chave or "fclose" in chave or "fprintf" in chave or "fscanf" in chave or "arquivo" in chave:
        return '#include <stdio.h>\n\nint main() {\n    FILE *arquivo = fopen("saida.txt", "w");\n    fprintf(arquivo, "Curso de C");\n    fclose(arquivo);\n    printf("Arquivo gravado\\n");\n    return 0;\n}'
    if "math" in chave:
        return '#include <stdio.h>\n#include <math.h>\n\nint main() {\n    printf("%.0f\\n", sqrt(25));\n    return 0;\n}'
    if "bit" in chave or "máscara" in chave:
        return '#include <stdio.h>\n\nint main() {\n    int permissoes = 6;\n    int leitura = 2;\n    printf("%d\\n", permissoes & leitura);\n    return 0;\n}'
    if "busca" in chave:
        return '#include <stdio.h>\n\nint main() {\n    int valores[4] = {4, 8, 15, 16};\n    int alvo = 15;\n    for (int i = 0; i < 4; i++) {\n        if (valores[i] == alvo) printf("Encontrado\\n");\n    }\n    return 0;\n}'
    if "bubble" in chave or "sort" in chave:
        return '#include <stdio.h>\n\nint main() {\n    int v[3] = {3, 1, 2};\n    for (int i = 0; i < 2; i++) {\n        for (int j = 0; j < 2 - i; j++) {\n            if (v[j] > v[j + 1]) {\n                int temp = v[j];\n                v[j] = v[j + 1];\n                v[j + 1] = temp;\n            }\n        }\n    }\n    printf("%d %d %d\\n", v[0], v[1], v[2]);\n    return 0;\n}'

    return f'#include <stdio.h>\n\nint main(void) {{\n    printf("Estudo de {conteudo} em C\\n");\n    return 0;\n}}'


TESTES_EXTRAS_CORRECAO = {
    "scanf": [
        {"entrada": "20 22\n", "saida_contem": ["Soma: 42"]},
    ],
    "divisão": [
        {"entrada": "9 4\n", "saida_contem": ["Resultado: 2.25"]},
        {
            "entrada": "9 0\n",
            "saida_obrigatoria": True,
            "saida_nao_contem": ["inf", "nan"],
        },
    ],
    "if": [
        {
            "entrada": "-3\n",
            "saida_obrigatoria": False,
            "saida_nao_contem": ["Positivo"],
        },
    ],
    "else": [
        {"entrada": "18\n", "saida_contem": ["Maior de idade"]},
    ],
    "else if": [
        {"entrada": "9\n", "saida_regex": [r"\bA\b"]},
        {"entrada": "5\n", "saida_regex": [r"\bC\b"]},
    ],
    "switch": [
        {"entrada": "1\n", "saida_contem": ["Cadastrar"]},
        {"entrada": "3\n", "saida_contem": ["Sair"]},
        {"entrada": "9\n", "saida_contem": ["invalida"]},
    ],
    "fgets": [
        {"entrada": "Joao da Silva\n", "saida_contem": ["Ola, Joao da Silva"]},
    ],
    "stdio": [
        {"entrada": "-4\n", "saida_contem": ["-8"]},
    ],
    "buffer overflow": [
        {"entrada": "123456789abcdef\n", "saida_contem": ["123456789"]},
    ],
    "validação": [
        {"entrada": "150\n", "saida_contem": ["Entrada invalida"]},
        {"entrada": "-1\n", "saida_contem": ["Entrada invalida"]},
    ],
    "calculadora": [
        {"entrada": "10 - 3\n", "saida_contem": ["Resultado: 7.00"]},
    ],
    "cadastro": [
        {"entrada": "Bia 18\n", "saida_contem": ["Bia tem 18 anos"]},
    ],
    "jogo terminal": [
        {"entrada": "42\n", "saida_contem": ["Acertou"]},
    ],
    "projeto final": [
        {"entrada": "6 6 9\n", "saida_contem": ["Media: 7.00"]},
    ],
}


def regra_correcao_para_conteudo(conteudo):
    plano_licao = obter_plano(conteudo)
    if plano_licao:
        regra = dict(plano_licao["correcao"])
        testes_base = [dict(teste) for teste in regra.get("testes", [])]
        testes_extras = [dict(teste) for teste in TESTES_EXTRAS_CORRECAO.get(conteudo, [])]
        if testes_base or testes_extras:
            regra["testes"] = testes_base + testes_extras
        return regra
    return {"codigo_contem": ["printf"], "saida_obrigatoria": True}


def codigo_inicial_para_conteudo(conteudo):
    chave = conteudo.lower()
    cabecalhos = ["#include <stdio.h>"]

    if any(item in chave for item in ["string", "strlen", "strcpy", "strcmp", "strcat", "fgets", "agenda", "editor texto"]):
        cabecalhos.append("#include <string.h>")
    if any(item in chave for item in ["malloc", "calloc", "realloc", "free", "memory leak", "stdlib", "listas"]):
        cabecalhos.append("#include <stdlib.h>")
    if chave == "math":
        cabecalhos.append("#include <math.h>")

    return (
        "\n".join(cabecalhos)
        + "\n\nint main(void) {\n"
        + f"    /* TODO: resolva o desafio sobre {conteudo}. */\n"
        + "    return 0;\n"
        + "}"
    )


def criar_alternativas(conteudos_modulo, resposta):
    alternativas = [resposta]
    for item in conteudos_modulo:
        if item != resposta and item not in alternativas:
            alternativas.append(item)
        if len(alternativas) == 4:
            break

    for item in ["printf", "scanf", "main", "for", "struct"]:
        if len(alternativas) == 4:
            break
        if item not in alternativas:
            alternativas.append(item)

    return alternativas[:4]


def gerar_trilha_completa_c():
    proximo_id = 1
    trilha = []

    for modulo in TRILHA_COMPLETA_C:
        modulo_licoes = []
        topicos = "; ".join(modulo["topicos"])

        for conteudo in modulo["conteudos"]:
            codigo = codigo_exemplo_para_conteudo(conteudo)
            plano_licao = obter_plano(conteudo)
            if plano_licao:
                conteudo_teorico = plano_licao["teoria"]
                pontos_chave = [
                    plano_licao["fundamento"],
                    f"Aplicação prática: {plano_licao['desafio']}",
                    "Compile com avisos habilitados e teste também valores de fronteira.",
                ]
                erro_comum = plano_licao["cuidado"]
                desafio_codigo = plano_licao["desafio"]
                resposta_quiz = plano_licao["fundamento"]
                alternativas_quiz = [
                    resposta_quiz,
                    f"{conteudo} elimina a necessidade de validar dados e resultados.",
                    f"{conteudo} só pode ser usado dentro da função main.",
                    f"O compilador corrige automaticamente qualquer uso incorreto de {conteudo}.",
                ]
            else:
                conteudo_teorico = (
                    f"{conteudo} faz parte do módulo {modulo['titulo']}. "
                    f"Nesta lição você estuda: {topicos}."
                )
                pontos_chave = modulo["topicos"][:3]
                erro_comum = "Não testar o programa com entradas diferentes."
                desafio_codigo = f"Faça um programa em C que demonstre {conteudo} e mostre uma saída no terminal."
                resposta_quiz = conteudo
                alternativas_quiz = criar_alternativas(modulo["conteudos"], conteudo)

            licao_dados = {
                "id": proximo_id,
                "titulo": conteudo,
                "conteudo": conteudo_teorico,
                "pontos_chave": pontos_chave,
                "erro_comum": erro_comum,
                "explicacao_codigo": (
                    "Observe a ordem das declarações, os tipos usados e como a saída confirma o resultado. "
                    "O exemplo é completo, compatível com C11 e pode ser compilado como um único arquivo."
                ),
                "codigo": codigo,
                "pergunta": f"Qual afirmação sobre {conteudo} está correta?",
                "alternativas": alternativas_quiz,
                "resposta": resposta_quiz,
                "exercicio_codigo": desafio_codigo,
                "codigo_minimo": codigo_inicial_para_conteudo(conteudo),
                "correcao": regra_correcao_para_conteudo(conteudo),
                "pratica_codigo": True
            }

            ajustes = AJUSTES_DIDATICOS_LICOES.get(conteudo)
            if ajustes:
                licao_dados.update(ajustes)

            desafios_teoricos = montar_desafios_teoricos_licao(
                conteudo,
                modulo,
                plano_licao,
                licao_dados["pergunta"],
                licao_dados["alternativas"],
                licao_dados["resposta"],
                aplicacao=licao_dados["exercicio_codigo"],
                semente=f"{modulo['id']}-{proximo_id}",
            )
            licao_dados["pergunta"] = desafios_teoricos[0]["pergunta"]
            licao_dados["alternativas"] = desafios_teoricos[0]["alternativas"]
            licao_dados["desafios_teoricos"] = desafios_teoricos

            modulo_licoes.append(licao_dados)
            proximo_id += 1

        trilha.append({
            "id": modulo["id"],
            "titulo": modulo["titulo"],
            "descricao": modulo["descricao"],
            "icone": modulo["icone"],
            "licoes": modulo_licoes,
        })

    return trilha


MODULOS = gerar_trilha_completa_c()
DESAFIOS_DIARIOS = gerar_desafios_diarios(MODULOS)

if len(PLANOS_LICOES) != sum(len(modulo["licoes"]) for modulo in MODULOS):
    raise RuntimeError("O catálogo pedagógico precisa cobrir todas as lições da trilha.")


def conectar():
    pasta = os.path.dirname(DB_PATH)
    if pasta:
        os.makedirs(pasta, exist_ok=True)

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def coluna_existe(conn, tabela, coluna):
    colunas = conn.execute(f"PRAGMA table_info({tabela})").fetchall()
    return any(c["name"] == coluna for c in colunas)


def adicionar_coluna(conn, tabela, coluna, definicao):
    if not coluna_existe(conn, tabela, coluna):
        conn.execute(f"ALTER TABLE {tabela} ADD COLUMN {coluna} {definicao}")


def iniciar_banco():
    conn = conectar()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            senha TEXT NOT NULL,
            xp INTEGER DEFAULT 0,
            nivel INTEGER DEFAULT 1,
            sequencia INTEGER DEFAULT 0,
            ultimo_acesso TEXT,
            melhor_sequencia INTEGER DEFAULT 0,
            ultima_atividade TEXT,
            protecoes_sequencia INTEGER DEFAULT 1
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS progresso (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            licao_id INTEGER NOT NULL,
            modulo_id INTEGER NOT NULL,
            quiz_correto INTEGER DEFAULT 0,
            quiz_respondido INTEGER DEFAULT 0,
            resposta_teorica TEXT,
            codigo_enviado INTEGER DEFAULT 0,
            concluida INTEGER DEFAULT 0,
            codigo_usuario TEXT,
            saida_codigo TEXT,
            entrada_codigo TEXT,
            codigo_validado INTEGER DEFAULT 0,
            feedback_codigo TEXT,
            atualizado_em TEXT,
            UNIQUE(usuario_id, licao_id)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS conquistas_usuario (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            nome TEXT NOT NULL,
            icone TEXT NOT NULL,
            descricao TEXT,
            raridade TEXT DEFAULT 'comum',
            desbloqueada_em TEXT,
            UNIQUE(usuario_id, nome)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS desafios_diarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            data TEXT NOT NULL,
            desafio_id TEXT,
            codigo_usuario TEXT,
            saida_codigo TEXT,
            entrada_codigo TEXT,
            codigo_validado INTEGER DEFAULT 0,
            feedback_codigo TEXT,
            concluido INTEGER DEFAULT 0,
            UNIQUE(usuario_id, data)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS compilador_historico (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            codigo TEXT,
            entrada TEXT,
            saida TEXT,
            build_log TEXT,
            criado_em TEXT
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS backups_progresso (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            caminho TEXT,
            dados_json TEXT,
            criado_em TEXT
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS metas_usuario (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            tipo TEXT NOT NULL,
            alvo_licoes INTEGER DEFAULT 1,
            alvo_desafios INTEGER DEFAULT 0,
            atualizado_em TEXT,
            UNIQUE(usuario_id, tipo)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS simulados_usuario (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            acertos INTEGER DEFAULT 0,
            total INTEGER DEFAULT 0,
            percentual INTEGER DEFAULT 0,
            criado_em TEXT
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS atividades_estudo (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            data TEXT NOT NULL,
            quizzes INTEGER DEFAULT 0,
            licoes INTEGER DEFAULT 0,
            desafios INTEGER DEFAULT 0,
            xp_ganho INTEGER DEFAULT 0,
            UNIQUE(usuario_id, data)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS recompensas_diarias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            data TEXT NOT NULL,
            missao_id TEXT NOT NULL,
            xp INTEGER DEFAULT 0,
            recebida_em TEXT,
            UNIQUE(usuario_id, data, missao_id)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS favoritos_usuario (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            licao_id INTEGER NOT NULL,
            criado_em TEXT NOT NULL,
            UNIQUE(usuario_id, licao_id)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS revisoes_usuario (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            licao_id INTEGER NOT NULL,
            nivel INTEGER DEFAULT 0,
            proxima_revisao TEXT NOT NULL,
            ultima_revisao TEXT,
            acertos INTEGER DEFAULT 0,
            erros INTEGER DEFAULT 0,
            UNIQUE(usuario_id, licao_id)
        )
    """)

    # Migração para bancos antigos já criados antes das novas funções.
    adicionar_coluna(conn, "progresso", "quiz_correto", "INTEGER DEFAULT 0")
    adicionar_coluna(conn, "progresso", "quiz_respondido", "INTEGER DEFAULT 0")
    adicionar_coluna(conn, "progresso", "resposta_teorica", "TEXT")
    adicionar_coluna(conn, "progresso", "codigo_enviado", "INTEGER DEFAULT 0")
    adicionar_coluna(conn, "progresso", "codigo_usuario", "TEXT")
    adicionar_coluna(conn, "progresso", "saida_codigo", "TEXT")
    adicionar_coluna(conn, "progresso", "entrada_codigo", "TEXT")
    adicionar_coluna(conn, "progresso", "codigo_validado", "INTEGER DEFAULT 0")
    adicionar_coluna(conn, "progresso", "feedback_codigo", "TEXT")
    adicionar_coluna(conn, "progresso", "atualizado_em", "TEXT")

    adicionar_coluna(conn, "usuarios", "xp", "INTEGER DEFAULT 0")
    adicionar_coluna(conn, "usuarios", "nivel", "INTEGER DEFAULT 1")
    adicionar_coluna(conn, "usuarios", "sequencia", "INTEGER DEFAULT 1")
    adicionar_coluna(conn, "usuarios", "ultimo_acesso", "TEXT")
    adicionar_coluna(conn, "usuarios", "melhor_sequencia", "INTEGER DEFAULT 0")
    adicionar_coluna(conn, "usuarios", "ultima_atividade", "TEXT")
    adicionar_coluna(conn, "usuarios", "protecoes_sequencia", "INTEGER DEFAULT 1")
    adicionar_coluna(conn, "desafios_diarios", "desafio_id", "TEXT")
    adicionar_coluna(conn, "desafios_diarios", "entrada_codigo", "TEXT")
    adicionar_coluna(conn, "desafios_diarios", "codigo_validado", "INTEGER DEFAULT 0")
    adicionar_coluna(conn, "desafios_diarios", "feedback_codigo", "TEXT")
    adicionar_coluna(conn, "conquistas_usuario", "descricao", "TEXT")
    adicionar_coluna(conn, "conquistas_usuario", "raridade", "TEXT DEFAULT 'comum'")
    adicionar_coluna(conn, "conquistas_usuario", "desbloqueada_em", "TEXT")
    adicionar_coluna(conn, "compilador_historico", "contexto", "TEXT DEFAULT 'livre'")
    adicionar_coluna(conn, "compilador_historico", "licao_id", "INTEGER")
    adicionar_coluna(conn, "compilador_historico", "modulo_id", "INTEGER")
    adicionar_coluna(conn, "compilador_historico", "aprovado", "INTEGER DEFAULT 0")
    adicionar_coluna(conn, "compilador_historico", "origem", "TEXT")

    conn.execute("""
        UPDATE usuarios
        SET melhor_sequencia = MAX(COALESCE(melhor_sequencia, 0), COALESCE(sequencia, 0))
    """)

    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_atividades_usuario_data
        ON atividades_estudo(usuario_id, data)
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_recompensas_usuario_data
        ON recompensas_diarias(usuario_id, data)
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_progresso_usuario_modulo
        ON progresso(usuario_id, modulo_id, concluida)
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_historico_usuario_data
        ON compilador_historico(usuario_id, id DESC)
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_favoritos_usuario
        ON favoritos_usuario(usuario_id, licao_id)
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_revisoes_usuario_data
        ON revisoes_usuario(usuario_id, proxima_revisao)
    """)

    # Quem já concluiu lição em versão antiga recebe permissão de rever e continuar.
    conn.execute("""
        UPDATE progresso
        SET quiz_correto = 1
        WHERE concluida = 1 AND (quiz_correto IS NULL OR quiz_correto = 0)
    """)

    conn.execute("PRAGMA optimize")

    conn.commit()
    conn.close()

def usuario_logado():
    if "usuario_id" not in session:
        return None

    conn = conectar()
    usuario = conn.execute("SELECT * FROM usuarios WHERE id = ?", (session["usuario_id"],)).fetchone()
    conn.close()
    return usuario


def total_licoes():
    return sum(len(m["licoes"]) for m in MODULOS)


def contar_concluidas(usuario_id):
    conn = conectar()
    total = conn.execute(
        "SELECT COUNT(*) AS total FROM progresso WHERE usuario_id = ? AND concluida = 1",
        (usuario_id,)
    ).fetchone()["total"]
    conn.close()
    return total


def encontrar_licao(licao_id):
    for modulo in MODULOS:
        for licao in modulo["licoes"]:
            if licao["id"] == licao_id:
                return modulo, licao
    return None, None


def modulo_liberado(usuario_id, modulo_id):
    if modulo_id == 1:
        return True

    modulo_anterior = next((m for m in MODULOS if m["id"] == modulo_id - 1), None)
    if not modulo_anterior:
        return False

    ids_licoes = [l["id"] for l in modulo_anterior["licoes"]]
    placeholders = ",".join("?" for _ in ids_licoes)

    conn = conectar()
    params = [usuario_id] + ids_licoes
    concluidas = conn.execute(
        f"SELECT COUNT(*) AS total FROM progresso WHERE usuario_id = ? AND licao_id IN ({placeholders}) AND concluida = 1",
        params
    ).fetchone()["total"]
    conn.close()

    return concluidas == len(ids_licoes)


def modulo_acessivel(usuario_id, modulo_id):
    """
    Permite acessar:
    - módulos liberados;
    - módulos que o usuário já começou;
    - módulos com lições já concluídas.
    Assim o usuário consegue voltar em lições já feitas.
    """
    if modulo_liberado(usuario_id, modulo_id):
        return True

    conn = conectar()
    registro = conn.execute(
        "SELECT id FROM progresso WHERE usuario_id = ? AND modulo_id = ? LIMIT 1",
        (usuario_id, modulo_id)
    ).fetchone()
    conn.close()

    return registro is not None


def licao_acessivel_para_usuario(usuario_id, licao_id, exigir_pratica=False):
    try:
        licao_id = int(licao_id)
    except (TypeError, ValueError):
        return None, None, ("Informe uma lição válida.", 400)

    modulo, licao = encontrar_licao(licao_id)
    if not licao:
        return None, None, ("Lição não encontrada.", 404)

    if not modulo_acessivel(usuario_id, modulo["id"]):
        return None, None, ("Conclua os módulos anteriores para acessar esta lição.", 403)

    if exigir_pratica and not licao.get("pratica_codigo", True):
        return None, None, ("Esta lição possui apenas atividades teóricas.", 400)

    return modulo, licao, None


def modulo_maximo_para_desafio_diario(usuario_id):
    modulo_maximo = 1

    for modulo in MODULOS:
        if modulo_liberado(usuario_id, modulo["id"]):
            modulo_maximo = modulo["id"]
        else:
            break

    return modulo_maximo


def desafios_diarios_do_usuario(usuario_id):
    modulo_maximo = modulo_maximo_para_desafio_diario(usuario_id)
    desafios = desafios_disponiveis_por_progresso(DESAFIOS_DIARIOS, modulo_maximo)
    return desafios, modulo_maximo


def desafio_do_dia_usuario(usuario_id, data_texto=None):
    desafios, _ = desafios_diarios_do_usuario(usuario_id)
    return escolher_desafio_do_dia(desafios, data_texto)


def progresso_modulo(usuario_id, modulo):
    ids = [l["id"] for l in modulo["licoes"]]
    if not ids:
        return 0

    placeholders = ",".join("?" for _ in ids)
    params = [usuario_id] + ids

    conn = conectar()
    concluidas = conn.execute(
        f"SELECT COUNT(*) AS total FROM progresso WHERE usuario_id = ? AND licao_id IN ({placeholders}) AND concluida = 1",
        params
    ).fetchone()["total"]
    conn.close()

    return int((concluidas / len(ids)) * 100)


def atualizar_nivel(usuario_id):
    conn = conectar()
    usuario = conn.execute("SELECT xp FROM usuarios WHERE id = ?", (usuario_id,)).fetchone()
    nivel = max(1, usuario["xp"] // 250 + 1)
    conn.execute("UPDATE usuarios SET nivel = ? WHERE id = ?", (nivel, usuario_id))
    conn.commit()
    conn.close()


def conceder_conquistas(usuario_id):
    conn = conectar()
    novas = sincronizar_conquistas(
        conn,
        usuario_id,
        total_licoes(),
        len(MODULOS[0]["licoes"]),
    )
    conn.commit()
    conn.close()
    return novas


def proxima_licao_usuario(usuario_id):
    conn = conectar()
    concluidas = {
        linha["licao_id"]
        for linha in conn.execute(
            "SELECT licao_id FROM progresso WHERE usuario_id = ? AND concluida = 1",
            (usuario_id,),
        ).fetchall()
    }
    conn.close()

    for modulo in MODULOS:
        if not modulo_liberado(usuario_id, modulo["id"]):
            break
        for licao in modulo["licoes"]:
            if licao["id"] not in concluidas:
                return {
                    "modulo_id": modulo["id"],
                    "modulo": modulo["titulo"],
                    "licao_id": licao["id"],
                    "licao": licao["titulo"],
                    "progresso": progresso_modulo(usuario_id, modulo),
                    "concluido": False,
                }

    ultimo_modulo = MODULOS[-1]
    ultima_licao = ultimo_modulo["licoes"][-1]
    return {
        "modulo_id": ultimo_modulo["id"],
        "modulo": ultimo_modulo["titulo"],
        "licao_id": ultima_licao["id"],
        "licao": ultima_licao["titulo"],
        "progresso": 100,
        "concluido": True,
    }


def desafio_por_id(desafio_id, usuario_id=None):
    if usuario_id:
        desafios, _ = desafios_diarios_do_usuario(usuario_id)
    else:
        desafios = DESAFIOS_DIARIOS

    return desafio_diario_por_id(desafios, desafio_id)


def desafio_do_dia(data_texto=None, usuario_id=None):
    if usuario_id:
        return desafio_do_dia_usuario(usuario_id, data_texto)

    return escolher_desafio_do_dia(DESAFIOS_DIARIOS, data_texto)


def linhas_para_dicts(linhas):
    return [dict(linha) for linha in linhas]


def criar_backup_progresso(usuario_id):
    conn = None
    try:
        conn = conectar()
        usuario = conn.execute(
            """
            SELECT id, nome, email, xp, nivel, sequencia, melhor_sequencia,
                   ultima_atividade, protecoes_sequencia, ultimo_acesso
            FROM usuarios WHERE id = ?
            """,
            (usuario_id,)
        ).fetchone()

        if not usuario:
            conn.close()
            return None

        dados = {
            "gerado_em": datetime.now().isoformat(timespec="seconds"),
            "usuario": dict(usuario),
            "progresso": linhas_para_dicts(conn.execute(
                "SELECT * FROM progresso WHERE usuario_id = ? ORDER BY modulo_id, licao_id",
                (usuario_id,)
            ).fetchall()),
            "desafios_diarios": linhas_para_dicts(conn.execute(
                "SELECT * FROM desafios_diarios WHERE usuario_id = ? ORDER BY data DESC",
                (usuario_id,)
            ).fetchall()),
            "conquistas": linhas_para_dicts(conn.execute(
                "SELECT * FROM conquistas_usuario WHERE usuario_id = ? ORDER BY id",
                (usuario_id,)
            ).fetchall()),
            "metas": linhas_para_dicts(conn.execute(
                "SELECT * FROM metas_usuario WHERE usuario_id = ? ORDER BY tipo",
                (usuario_id,)
            ).fetchall()),
            "simulados": linhas_para_dicts(conn.execute(
                "SELECT * FROM simulados_usuario WHERE usuario_id = ? ORDER BY id DESC",
                (usuario_id,)
            ).fetchall()),
            "atividades_estudo": linhas_para_dicts(conn.execute(
                "SELECT * FROM atividades_estudo WHERE usuario_id = ? ORDER BY data DESC",
                (usuario_id,)
            ).fetchall()),
            "recompensas_diarias": linhas_para_dicts(conn.execute(
                "SELECT * FROM recompensas_diarias WHERE usuario_id = ? ORDER BY data DESC, id DESC",
                (usuario_id,)
            ).fetchall()),
            "historico_codigos": linhas_para_dicts(conn.execute(
                "SELECT * FROM compilador_historico WHERE usuario_id = ? ORDER BY id DESC LIMIT 100",
                (usuario_id,)
            ).fetchall()),
            "favoritos": linhas_para_dicts(conn.execute(
                "SELECT * FROM favoritos_usuario WHERE usuario_id = ? ORDER BY id DESC",
                (usuario_id,)
            ).fetchall()),
            "revisoes": linhas_para_dicts(conn.execute(
                "SELECT * FROM revisoes_usuario WHERE usuario_id = ? ORDER BY proxima_revisao",
                (usuario_id,)
            ).fetchall())
        }

        pasta_backup = os.environ.get("BACKUP_DIR") or os.path.join(
            os.path.dirname(DB_PATH) or ".", "backups"
        )
        os.makedirs(pasta_backup, exist_ok=True)
        caminho = os.path.join(pasta_backup, f"progresso_usuario_{usuario_id}.json")
        caminho_temporario = f"{caminho}.{os.getpid()}.{threading.get_ident()}.tmp"

        with open(caminho_temporario, "w", encoding="utf-8") as arquivo:
            json.dump(dados, arquivo, ensure_ascii=False, indent=2)
            arquivo.flush()
            os.fsync(arquivo.fileno())
        os.replace(caminho_temporario, caminho)

        dados_json = json.dumps(dados, ensure_ascii=False)
        conn.execute(
            "INSERT INTO backups_progresso (usuario_id, caminho, dados_json, criado_em) VALUES (?, ?, ?, ?)",
            (usuario_id, caminho, dados_json, dados["gerado_em"])
        )
        conn.execute(
            """
            DELETE FROM backups_progresso
            WHERE usuario_id = ? AND id NOT IN (
                SELECT id FROM backups_progresso
                WHERE usuario_id = ? ORDER BY id DESC LIMIT 20
            )
            """,
            (usuario_id, usuario_id),
        )
        conn.commit()
        conn.close()
        conn = None
        return {"caminho": caminho, "criado_em": dados["gerado_em"]}
    except Exception:
        if conn is not None:
            try:
                conn.rollback()
                conn.close()
            except Exception:
                pass
        return None


def backup_mais_recente(usuario_id):
    conn = conectar()
    backup = conn.execute(
        "SELECT * FROM backups_progresso WHERE usuario_id = ? ORDER BY id DESC LIMIT 1",
        (usuario_id,)
    ).fetchone()
    conn.close()
    return backup


def limitar_inteiro(valor, padrao, minimo=0, maximo=30):
    try:
        numero = int(valor)
    except (TypeError, ValueError):
        numero = padrao
    return max(minimo, min(maximo, numero))


def inicio_semana_atual():
    hoje = date.today()
    return hoje - timedelta(days=hoje.weekday())


def obter_metas_usuario(usuario_id):
    metas = {
        "diaria": {
            "tipo": "diaria",
            "titulo": "Meta diária",
            "periodo": "Hoje",
            "alvo_licoes": 1,
            "alvo_desafios": 1
        },
        "semanal": {
            "tipo": "semanal",
            "titulo": "Meta semanal",
            "periodo": "Semana atual",
            "alvo_licoes": 5,
            "alvo_desafios": 3
        }
    }

    conn = conectar()
    registros = conn.execute(
        "SELECT * FROM metas_usuario WHERE usuario_id = ?",
        (usuario_id,)
    ).fetchall()
    conn.close()

    for registro in registros:
        tipo = registro["tipo"]
        if tipo in metas:
            metas[tipo]["alvo_licoes"] = registro["alvo_licoes"]
            metas[tipo]["alvo_desafios"] = registro["alvo_desafios"]

    return metas


def porcentagem_meta(valor, alvo):
    if alvo <= 0:
        return 100 if valor > 0 else 0
    return min(100, int((valor / alvo) * 100))


def progresso_metas(usuario_id):
    metas = obter_metas_usuario(usuario_id)
    hoje = str(date.today())
    semana = str(inicio_semana_atual())

    conn = conectar()
    licoes_hoje = conn.execute(
        "SELECT COUNT(*) AS total FROM progresso WHERE usuario_id = ? AND concluida = 1 AND atualizado_em = ?",
        (usuario_id, hoje)
    ).fetchone()["total"]
    licoes_semana = conn.execute(
        "SELECT COUNT(*) AS total FROM progresso WHERE usuario_id = ? AND concluida = 1 AND atualizado_em >= ?",
        (usuario_id, semana)
    ).fetchone()["total"]
    desafios_hoje = conn.execute(
        "SELECT COUNT(*) AS total FROM desafios_diarios WHERE usuario_id = ? AND concluido = 1 AND data = ?",
        (usuario_id, hoje)
    ).fetchone()["total"]
    desafios_semana = conn.execute(
        "SELECT COUNT(*) AS total FROM desafios_diarios WHERE usuario_id = ? AND concluido = 1 AND data >= ?",
        (usuario_id, semana)
    ).fetchone()["total"]
    conn.close()

    realizados = {
        "diaria": {"licoes": licoes_hoje, "desafios": desafios_hoje},
        "semanal": {"licoes": licoes_semana, "desafios": desafios_semana}
    }

    metas_view = []
    for tipo in ("diaria", "semanal"):
        meta = metas[tipo]
        feito = realizados[tipo]
        metas_view.append({
            **meta,
            "feito_licoes": feito["licoes"],
            "feito_desafios": feito["desafios"],
            "percentual_licoes": porcentagem_meta(feito["licoes"], meta["alvo_licoes"]),
            "percentual_desafios": porcentagem_meta(feito["desafios"], meta["alvo_desafios"])
        })

    return metas_view


def resumo_desempenho(usuario_id):
    conn = conectar()
    quiz_total = conn.execute(
        "SELECT COUNT(*) AS total FROM progresso WHERE usuario_id = ? AND quiz_respondido = 1",
        (usuario_id,)
    ).fetchone()["total"]
    quiz_corretos = conn.execute(
        "SELECT COUNT(*) AS total FROM progresso WHERE usuario_id = ? AND quiz_correto = 1",
        (usuario_id,)
    ).fetchone()["total"]
    codigos_validados = conn.execute(
        "SELECT COUNT(*) AS total FROM progresso WHERE usuario_id = ? AND codigo_validado = 1",
        (usuario_id,)
    ).fetchone()["total"]
    desafios_concluidos = conn.execute(
        "SELECT COUNT(*) AS total FROM desafios_diarios WHERE usuario_id = ? AND concluido = 1",
        (usuario_id,)
    ).fetchone()["total"]
    ultimas_licoes = conn.execute(
        """
        SELECT licao_id, modulo_id, atualizado_em, codigo_validado, feedback_codigo
        FROM progresso
        WHERE usuario_id = ? AND atualizado_em IS NOT NULL
        ORDER BY atualizado_em DESC, id DESC
        LIMIT 6
        """,
        (usuario_id,)
    ).fetchall()
    simulados = conn.execute(
        "SELECT * FROM simulados_usuario WHERE usuario_id = ? ORDER BY id DESC LIMIT 5",
        (usuario_id,)
    ).fetchall()
    conn.close()

    atividades = []
    for item in ultimas_licoes:
        modulo, licao = encontrar_licao(item["licao_id"])
        if licao:
            atividades.append({
                "modulo": modulo["titulo"],
                "licao": licao["titulo"],
                "data": item["atualizado_em"],
                "codigo_validado": item["codigo_validado"],
                "feedback": item["feedback_codigo"]
            })

    total_quiz = max(quiz_total, 1)
    return {
        "quiz_total": quiz_total,
        "quiz_corretos": quiz_corretos,
        "taxa_quiz": int((quiz_corretos / total_quiz) * 100),
        "codigos_validados": codigos_validados,
        "desafios_concluidos": desafios_concluidos,
        "atividades": atividades,
        "simulados": simulados
    }


def relatorio_modulos(usuario_id):
    conn = conectar()
    progresso_usuario = {
        linha["licao_id"]: linha
        for linha in conn.execute(
            "SELECT * FROM progresso WHERE usuario_id = ?",
            (usuario_id,),
        ).fetchall()
    }
    favoritos = {
        linha["licao_id"]
        for linha in conn.execute(
            "SELECT licao_id FROM favoritos_usuario WHERE usuario_id = ?",
            (usuario_id,),
        ).fetchall()
    }
    tentativas_por_modulo = {
        linha["modulo_id"]: linha
        for linha in conn.execute(
            """
            SELECT modulo_id, COUNT(*) AS tentativas,
                   SUM(CASE WHEN aprovado = 1 THEN 1 ELSE 0 END) AS aprovadas
            FROM compilador_historico
            WHERE usuario_id = ? AND modulo_id IS NOT NULL
            GROUP BY modulo_id
            """,
            (usuario_id,),
        ).fetchall()
    }
    conn.close()

    modulos_relatorio = []
    for modulo in MODULOS:
        registros = [
            progresso_usuario[licao["id"]]
            for licao in modulo["licoes"]
            if licao["id"] in progresso_usuario
        ]
        concluidas = sum(1 for item in registros if item["concluida"] == 1)
        teorias_dominadas = sum(1 for item in registros if item["quiz_correto"] == 1)
        praticas_total = sum(1 for licao in modulo["licoes"] if licao.get("pratica_codigo", True))
        praticas_aprovadas = sum(1 for item in registros if item["codigo_validado"] == 1)
        tentativas = tentativas_por_modulo.get(modulo["id"])
        progresso = int((concluidas / len(modulo["licoes"])) * 100) if modulo["licoes"] else 0
        modulos_relatorio.append({
            "id": modulo["id"],
            "titulo": modulo["titulo"],
            "descricao": modulo["descricao"],
            "icone": modulo["icone"],
            "progresso": progresso,
            "concluidas": concluidas,
            "total": len(modulo["licoes"]),
            "liberado": modulo_acessivel(usuario_id, modulo["id"]),
            "iniciadas": len(registros),
            "teorias_dominadas": teorias_dominadas,
            "praticas_aprovadas": praticas_aprovadas,
            "praticas_total": praticas_total,
            "tentativas_codigo": tentativas["tentativas"] if tentativas else 0,
            "aprovacoes_codigo": tentativas["aprovadas"] if tentativas else 0,
            "favoritos": sum(1 for licao in modulo["licoes"] if licao["id"] in favoritos),
        })
    return modulos_relatorio


def montar_questoes_simulado(usuario_id, quantidade=10):
    licoes = []
    for modulo in MODULOS:
        if modulo_acessivel(usuario_id, modulo["id"]):
            for licao in modulo["licoes"]:
                if licao.get("pergunta") and licao.get("alternativas") and licao.get("resposta"):
                    licoes.append((modulo, licao))

    if not licoes:
        for modulo in MODULOS[:1]:
            for licao in modulo["licoes"]:
                licoes.append((modulo, licao))

    if not licoes:
        return []

    deslocamento = (date.today().toordinal() + usuario_id) % len(licoes)
    licoes = licoes[deslocamento:] + licoes[:deslocamento]

    questoes = []
    for modulo, licao in licoes[:quantidade]:
        questoes.append({
            "id": licao["id"],
            "modulo": modulo["titulo"],
            "pergunta": licao["pergunta"],
            "alternativas": licao["alternativas"],
            "resposta": licao["resposta"]
        })
    return questoes


def montar_terminal_unificado(saida, entrada="", codigo_retorno=0):
    saida_final = saida or "Programa executado sem saída na tela."
    if "Process returned" not in saida_final:
        saida_final = saida_final.rstrip() + f"\n\nProcess returned {codigo_retorno}."
    return saida_final


def detectar_prompt_entrada(codigo):
    achou = re.search(r'printf\s*\(\s*"([^"]*)"\s*\)\s*;\s*scanf', codigo or "", re.S)
    if achou:
        return achou.group(1).replace("\\n", "\n").replace("\\t", "\t")
    if "scanf" in (codigo or ""):
        return "Entrada:"
    return ""



def executar_com_piston(codigo, entrada=""):
    return compilador_seguro.executar_piston(codigo, entrada)


def executar_compilador_online(codigo, entrada=""):
    return compilador_seguro.executar_codigo(codigo, entrada)


def normalizar_texto(texto):
    texto = (texto or "").lower()
    texto = unicodedata.normalize("NFD", texto)
    texto = "".join(char for char in texto if unicodedata.category(char) != "Mn")
    return texto


def limpar_saida_para_correcao(saida):
    linhas = []
    for linha in (saida or "").splitlines():
        normalizada = normalizar_texto(linha).strip()
        if normalizada.startswith("process returned"):
            continue
        if normalizada.startswith("press any key"):
            continue
        if normalizada.startswith("origem:"):
            continue
        linhas.append(linha)
    return "\n".join(linhas).strip()


def remover_comentarios_c(codigo):
    """Remove comentarios sem apagar textos e caracteres literais."""
    resultado = []
    indice = 0
    estado = "codigo"
    escape = False

    while indice < len(codigo or ""):
        atual = codigo[indice]
        proximo = codigo[indice + 1] if indice + 1 < len(codigo) else ""

        if estado == "linha":
            if atual == "\n":
                resultado.append(atual)
                estado = "codigo"
            indice += 1
            continue

        if estado == "bloco":
            if atual == "*" and proximo == "/":
                estado = "codigo"
                indice += 2
                continue
            if atual == "\n":
                resultado.append(atual)
            indice += 1
            continue

        if estado in {"texto", "caractere"}:
            resultado.append(atual)
            if escape:
                escape = False
            elif atual == "\\":
                escape = True
            elif (estado == "texto" and atual == '"') or (estado == "caractere" and atual == "'"):
                estado = "codigo"
            indice += 1
            continue

        if atual == "/" and proximo == "/":
            estado = "linha"
            indice += 2
        elif atual == "/" and proximo == "*":
            estado = "bloco"
            indice += 2
        else:
            resultado.append(atual)
            if atual == '"':
                estado = "texto"
            elif atual == "'":
                estado = "caractere"
            indice += 1

    return "".join(resultado)


def validar_regras_estaticas(codigo, regra):
    falhas = []
    codigo_normalizado = normalizar_texto(remover_comentarios_c(codigo))

    for termo in regra.get("codigo_contem", []):
        if normalizar_texto(termo) not in codigo_normalizado:
            falhas.append(f"O código precisa usar: {termo}.")

    for termo in regra.get("codigo_nao_contem", []):
        if normalizar_texto(termo) in codigo_normalizado:
            falhas.append(f"Remova o uso de: {termo}.")

    for termo, minimo in regra.get("min_ocorrencias_codigo", {}).items():
        if codigo_normalizado.count(normalizar_texto(termo)) < minimo:
            falhas.append(f"Use {termo} pelo menos {minimo} vezes.")

    return falhas


def validar_saida(saida, regra):
    falhas = []
    saida_limpa = limpar_saida_para_correcao(saida)
    saida_normalizada = normalizar_texto(saida_limpa)

    if regra.get("saida_obrigatoria") and not saida_limpa:
        falhas.append("O programa precisa mostrar alguma saída na tela.")

    for termo in regra.get("saida_contem", []):
        if normalizar_texto(termo) not in saida_normalizada:
            falhas.append(f"A saída precisa conter: {termo}.")

    for termo in regra.get("saida_nao_contem", []):
        if normalizar_texto(termo) in saida_normalizada:
            falhas.append(f"A saída não pode conter: {termo}.")

    for expressao in regra.get("saida_regex", []):
        if not re.search(expressao, saida_normalizada, re.I):
            falhas.append("A saída ainda não bate com o resultado esperado.")

    minimo_linhas = regra.get("min_linhas_saida")
    if minimo_linhas:
        linhas = [linha for linha in saida_limpa.splitlines() if linha.strip()]
        if len(linhas) < minimo_linhas:
            falhas.append(f"A saída precisa ter pelo menos {minimo_linhas} linhas.")

    return falhas


def avaliar_codigo_automaticamente(codigo, resultado_execucao, regra):
    if not resultado_execucao.get("ok", False):
        return {
            "ok": False,
            "mensagem": "Corrija os erros de compilação ou execução antes de concluir."
        }

    regra = regra or {"saida_obrigatoria": True}
    falhas = validar_regras_estaticas(codigo, regra)

    testes = regra.get("testes", [])
    if testes:
        for indice, teste in enumerate(testes, start=1):
            resultado_teste = executar_compilador_online(codigo, teste.get("entrada", ""))
            if not resultado_teste.get("ok", False):
                falhas.append(f"O teste automático {indice} não executou corretamente.")
                continue

            regra_saida_teste = {
                "saida_contem": teste.get("saida_contem", []),
                "saida_nao_contem": teste.get("saida_nao_contem", []),
                "saida_regex": teste.get("saida_regex", []),
                "saida_obrigatoria": teste.get("saida_obrigatoria", True)
            }
            falhas.extend(validar_saida(resultado_teste.get("saida", ""), regra_saida_teste))
    else:
        falhas.extend(validar_saida(resultado_execucao.get("saida", ""), regra))

    if falhas:
        return {
            "ok": False,
            "mensagem": " ".join(falhas[:3])
        }

    return {
        "ok": True,
        "mensagem": "Correção automática aprovada. Você pode concluir."
    }


def validar_codigo_recebido(codigo, entrada=None):
    return compilador_seguro.validar_codigo(codigo, entrada)


def comando_gcc(arquivo_c, arquivo_saida):
    return compilador_seguro.comando_gcc(arquivo_c, arquivo_saida)


def compilar_codigo_c(codigo):
    return compilador_seguro.compilar_codigo(codigo)


def executar_codigo_c(codigo, entrada=""):
    return compilador_seguro.executar_codigo_local(codigo, entrada)


@app.context_processor
def contexto():
    return {
        "usuario": usuario_logado(),
        "total_licoes": total_licoes()
    }


@app.route("/")
def index():
    if usuario_logado():
        return redirect(url_for("dashboard"))
    return render_template("public/index.html")


@app.route("/cadastro", methods=["GET", "POST"])
def cadastro():
    if request.method == "POST":
        nome = request.form["nome"].strip()
        email = request.form["email"].strip().lower()
        senha = request.form["senha"]

        conn = conectar()
        usuario_existente = conn.execute("SELECT id FROM usuarios WHERE email = ?", (email,)).fetchone()

        if usuario_existente:
            conn.close()
            return render_template("auth/cadastro.html", erro="Este e-mail já está cadastrado. Entre na conta em vez de criar outra.")

        senha_hash = generate_password_hash(senha)

        cur = conn.execute(
            """
            INSERT INTO usuarios
                (nome, email, senha, sequencia, melhor_sequencia, protecoes_sequencia, ultimo_acesso)
            VALUES (?, ?, ?, 0, 0, 1, ?)
            """,
            (nome, email, senha_hash, str(date.today()))
        )
        conn.commit()

        session.clear()
        session["usuario_id"] = cur.lastrowid
        novo_usuario_id = cur.lastrowid

        conn.close()
        criar_backup_progresso(novo_usuario_id)
        return redirect(url_for("dashboard"))

    return render_template("auth/cadastro.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        senha = request.form["senha"]

        conn = conectar()
        usuario = conn.execute("SELECT * FROM usuarios WHERE email = ?", (email,)).fetchone()

        if usuario and check_password_hash(usuario["senha"], senha):
            session.clear()
            session["usuario_id"] = usuario["id"]
            conn.execute("UPDATE usuarios SET ultimo_acesso = ? WHERE id = ?", (str(date.today()), usuario["id"]))
            conn.commit()
            conn.close()
            return redirect(url_for("dashboard"))

        conn.close()
        return render_template("auth/login.html", erro="E-mail ou senha incorretos.")

    return render_template("auth/login.html")


@app.route("/sair")
def sair():
    session.clear()
    return redirect(url_for("index"))


@app.route("/dashboard")
def dashboard():
    usuario = usuario_logado()
    if not usuario:
        return redirect(url_for("login"))

    concluidas = contar_concluidas(usuario["id"])
    porcentagem = int((concluidas / total_licoes()) * 100)
    conceder_conquistas(usuario["id"])
    desafios_disponiveis, _ = desafios_diarios_do_usuario(usuario["id"])
    sincronizar_revisoes_usuario(usuario["id"])

    conn = conectar()
    conquistas = conn.execute(
        "SELECT * FROM conquistas_usuario WHERE usuario_id = ? ORDER BY id DESC",
        (usuario["id"],)
    ).fetchall()

    ranking = conn.execute(
        "SELECT nome, xp, nivel FROM usuarios ORDER BY xp DESC, nivel DESC LIMIT 5"
    ).fetchall()
    backup_recente = conn.execute(
        "SELECT * FROM backups_progresso WHERE usuario_id = ? ORDER BY id DESC LIMIT 1",
        (usuario["id"],)
    ).fetchone()
    missoes = obter_missoes_diarias(conn, usuario["id"], bool(desafios_disponiveis))
    calendario = calendario_atividade(conn, usuario["id"])
    revisoes_pendentes = conn.execute(
        """
        SELECT COUNT(*) AS total FROM revisoes_usuario
        WHERE usuario_id = ? AND proxima_revisao <= ?
        """,
        (usuario["id"], date.today().isoformat()),
    ).fetchone()["total"]
    conn.close()

    modulos_view = []
    for modulo in MODULOS:
        progresso = progresso_modulo(usuario["id"], modulo)
        liberado = modulo_liberado(usuario["id"], modulo["id"])
        modulos_view.append({
            **modulo,
            "progresso": progresso,
            "liberado": liberado,
            "estrelas": 3 if progresso == 100 else 2 if progresso >= 67 else 1 if progresso > 0 else 0,
            "estado": "concluido" if progresso == 100 else "atual" if liberado else "bloqueado",
        })

    proxima_licao = proxima_licao_usuario(usuario["id"])
    indice_atual = max(0, proxima_licao["modulo_id"] - 1)
    inicio_destaques = max(0, indice_atual - 1)
    modulos_destaque = modulos_view[inicio_destaques:inicio_destaques + 3]

    return render_template(
        "app/dashboard.html",
        concluidas=concluidas,
        porcentagem=porcentagem,
        modulos=modulos_view,
        conquistas=conquistas,
        ranking=ranking,
        backup_recente=backup_recente,
        missoes=missoes,
        calendario=calendario,
        nivel_jogo=estado_nivel(usuario["xp"]),
        liga=liga_por_xp(usuario["xp"]),
        proxima_licao=proxima_licao,
        modulos_destaque=modulos_destaque,
        recompensa_mensagem=request.args.get("recompensa", ""),
        aviso_mensagem=request.args.get("aviso", ""),
        revisoes_pendentes=revisoes_pendentes,
    )


@app.route("/missoes/<missao_id>/resgatar", methods=["POST"])
def resgatar_recompensa_diaria(missao_id):
    usuario = usuario_logado()
    if not usuario:
        return redirect(url_for("login"))

    desafios_disponiveis, _ = desafios_diarios_do_usuario(usuario["id"])
    conn = conectar()
    resultado = resgatar_missao(
        conn,
        usuario["id"],
        missao_id,
        bool(desafios_disponiveis),
    )
    conn.commit()
    conn.close()

    if resultado["ok"]:
        atualizar_nivel(usuario["id"])
        conceder_conquistas(usuario["id"])
        criar_backup_progresso(usuario["id"])
        return redirect(url_for("dashboard", recompensa=resultado["mensagem"]))

    return redirect(url_for("dashboard", aviso=resultado["mensagem"]))


@app.route("/perfil")
def perfil():
    usuario = usuario_logado()
    if not usuario:
        return redirect(url_for("login"))

    concluidas = contar_concluidas(usuario["id"])
    porcentagem = int((concluidas / total_licoes()) * 100)
    desempenho = resumo_desempenho(usuario["id"])
    metas = progresso_metas(usuario["id"])
    modulos_relatorio = relatorio_modulos(usuario["id"])
    backup_recente = backup_mais_recente(usuario["id"])
    conceder_conquistas(usuario["id"])
    conn = conectar()
    conquistas = conn.execute(
        "SELECT * FROM conquistas_usuario WHERE usuario_id = ? ORDER BY id DESC",
        (usuario["id"],),
    ).fetchall()
    calendario = calendario_atividade(conn, usuario["id"])
    conn.close()

    return render_template(
        "app/perfil.html",
        concluidas=concluidas,
        porcentagem=porcentagem,
        desempenho=desempenho,
        metas=metas,
        modulos_relatorio=modulos_relatorio,
        backup_recente=backup_recente,
        conquistas=conquistas,
        calendario=calendario,
        liga=liga_por_xp(usuario["xp"]),
        nivel_jogo=estado_nivel(usuario["xp"]),
    )


def licoes_favoritas_usuario(usuario_id):
    conn = conectar()
    ids = {
        linha["licao_id"]
        for linha in conn.execute(
            "SELECT licao_id FROM favoritos_usuario WHERE usuario_id = ?",
            (usuario_id,),
        ).fetchall()
    }
    conn.close()
    return ids


@app.route("/favoritos")
def pagina_favoritos():
    usuario = usuario_logado()
    if not usuario:
        return redirect(url_for("login"))

    conn = conectar()
    registros = conn.execute(
        "SELECT * FROM favoritos_usuario WHERE usuario_id = ? ORDER BY id DESC",
        (usuario["id"],),
    ).fetchall()
    conn.close()

    favoritos = []
    for registro in registros:
        modulo, licao = encontrar_licao(registro["licao_id"])
        if modulo and licao:
            favoritos.append({
                "modulo": modulo,
                "licao": licao,
                "criado_em": registro["criado_em"],
                "liberado": modulo_acessivel(usuario["id"], modulo["id"]),
            })
    return render_template("learning/favoritos.html", favoritos=favoritos)


@app.route("/favoritos/<int:licao_id>", methods=["POST"])
def alternar_favorito(licao_id):
    usuario = usuario_logado()
    if not usuario:
        return redirect(url_for("login"))
    modulo, licao = encontrar_licao(licao_id)
    if not modulo or not licao or not modulo_acessivel(usuario["id"], modulo["id"]):
        return redirect(url_for("modulos"))

    conn = conectar()
    existente = conn.execute(
        "SELECT id FROM favoritos_usuario WHERE usuario_id = ? AND licao_id = ?",
        (usuario["id"], licao_id),
    ).fetchone()
    if existente:
        conn.execute("DELETE FROM favoritos_usuario WHERE id = ?", (existente["id"],))
    else:
        conn.execute(
            "INSERT INTO favoritos_usuario (usuario_id, licao_id, criado_em) VALUES (?, ?, ?)",
            (usuario["id"], licao_id, datetime.now().isoformat(timespec="seconds")),
        )
    conn.commit()
    conn.close()
    criar_backup_progresso(usuario["id"])

    destino = request.form.get("destino", "")
    if not destino.startswith("/") or destino.startswith("//"):
        destino = url_for("pagina_favoritos")
    return redirect(destino)


INTERVALOS_REVISAO = (1, 3, 7, 14, 30, 60)


def sincronizar_revisoes_usuario(usuario_id):
    conn = conectar()
    concluidas = conn.execute(
        """
        SELECT licao_id, atualizado_em FROM progresso
        WHERE usuario_id = ? AND concluida = 1
        """,
        (usuario_id,),
    ).fetchall()
    for registro in concluidas:
        try:
            base = date.fromisoformat(str(registro["atualizado_em"] or "")[:10])
        except ValueError:
            base = date.today()
        conn.execute(
            """
            INSERT OR IGNORE INTO revisoes_usuario
                (usuario_id, licao_id, nivel, proxima_revisao, acertos, erros)
            VALUES (?, ?, 0, ?, 0, 0)
            """,
            (usuario_id, registro["licao_id"], (base + timedelta(days=1)).isoformat()),
        )
    conn.commit()
    conn.close()


@app.route("/revisao")
def revisao():
    usuario = usuario_logado()
    if not usuario:
        return redirect(url_for("login"))
    sincronizar_revisoes_usuario(usuario["id"])

    hoje = date.today().isoformat()
    conn = conectar()
    pendentes = conn.execute(
        """
        SELECT * FROM revisoes_usuario
        WHERE usuario_id = ? AND proxima_revisao <= ?
        ORDER BY proxima_revisao, id LIMIT 10
        """,
        (usuario["id"], hoje),
    ).fetchall()
    proximas = conn.execute(
        """
        SELECT * FROM revisoes_usuario
        WHERE usuario_id = ? AND proxima_revisao > ?
        ORDER BY proxima_revisao LIMIT 6
        """,
        (usuario["id"], hoje),
    ).fetchall()
    conn.close()

    def montar_item(registro):
        modulo, licao = encontrar_licao(registro["licao_id"])
        return {"registro": registro, "modulo": modulo, "licao": licao}

    pendentes_view = [montar_item(item) for item in pendentes]
    proximas_view = [montar_item(item) for item in proximas]
    return render_template(
        "learning/revisao.html",
        pendentes=pendentes_view,
        proximas=proximas_view,
        mensagem=request.args.get("mensagem", ""),
        resultado=request.args.get("resultado", ""),
    )


@app.route("/revisao/<int:licao_id>", methods=["POST"])
def responder_revisao(licao_id):
    usuario = usuario_logado()
    if not usuario:
        return redirect(url_for("login"))
    modulo, licao = encontrar_licao(licao_id)
    if not modulo or not licao:
        return redirect(url_for("revisao"))

    conn = conectar()
    registro = conn.execute(
        """
        SELECT r.* FROM revisoes_usuario r
        JOIN progresso p ON p.usuario_id = r.usuario_id AND p.licao_id = r.licao_id
        WHERE r.usuario_id = ? AND r.licao_id = ? AND p.concluida = 1
        """,
        (usuario["id"], licao_id),
    ).fetchone()
    if not registro:
        conn.close()
        return redirect(url_for("revisao"))

    correta = request.form.get("resposta", "") == licao["resposta"]
    nivel_atual = int(registro["nivel"] or 0)
    novo_nivel = min(len(INTERVALOS_REVISAO) - 1, nivel_atual + 1) if correta else 0
    intervalo = INTERVALOS_REVISAO[novo_nivel]
    proxima = (date.today() + timedelta(days=intervalo)).isoformat()
    conn.execute(
        """
        UPDATE revisoes_usuario
        SET nivel = ?, proxima_revisao = ?, ultima_revisao = ?,
            acertos = acertos + ?, erros = erros + ?
        WHERE usuario_id = ? AND licao_id = ?
        """,
        (
            novo_nivel,
            proxima,
            datetime.now().isoformat(timespec="seconds"),
            1 if correta else 0,
            0 if correta else 1,
            usuario["id"],
            licao_id,
        ),
    )
    if correta:
        registrar_atividade(conn, usuario["id"], quizzes=1)
    conn.commit()
    conn.close()
    criar_backup_progresso(usuario["id"])

    mensagem = (
        f"Resposta correta. Próxima revisão em {intervalo} dia(s)."
        if correta
        else "Resposta incorreta. Revise a explicação e tente novamente amanhã."
    )
    return redirect(url_for("revisao", mensagem=mensagem, resultado="correto" if correta else "incorreto"))


@app.route("/metas", methods=["POST"])
def salvar_metas():
    usuario = usuario_logado()
    if not usuario:
        return redirect(url_for("login"))

    metas = {
        "diaria": {
            "alvo_licoes": limitar_inteiro(request.form.get("diaria_licoes"), 1, 0, 10),
            "alvo_desafios": limitar_inteiro(request.form.get("diaria_desafios"), 1, 0, 5)
        },
        "semanal": {
            "alvo_licoes": limitar_inteiro(request.form.get("semanal_licoes"), 5, 0, 30),
            "alvo_desafios": limitar_inteiro(request.form.get("semanal_desafios"), 3, 0, 14)
        }
    }

    conn = conectar()
    for tipo, valores in metas.items():
        conn.execute(
            """
            INSERT INTO metas_usuario (usuario_id, tipo, alvo_licoes, alvo_desafios, atualizado_em)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(usuario_id, tipo)
            DO UPDATE SET alvo_licoes = excluded.alvo_licoes,
                          alvo_desafios = excluded.alvo_desafios,
                          atualizado_em = excluded.atualizado_em
            """,
            (
                usuario["id"],
                tipo,
                valores["alvo_licoes"],
                valores["alvo_desafios"],
                datetime.now().isoformat(timespec="seconds")
            )
        )
    conn.commit()
    conn.close()
    criar_backup_progresso(usuario["id"])

    return redirect(url_for("perfil"))


@app.route("/simulado", methods=["GET", "POST"])
def simulado():
    usuario = usuario_logado()
    if not usuario:
        return redirect(url_for("login"))

    resultado = None
    resultados = []

    if request.method == "POST":
        ids_questoes = []
        for valor in request.form.getlist("questoes"):
            try:
                ids_questoes.append(int(valor))
            except ValueError:
                continue

        for licao_id in ids_questoes:
            modulo, licao = encontrar_licao(licao_id)
            if not licao:
                continue

            resposta = request.form.get(f"q_{licao_id}", "")
            correta = resposta == licao["resposta"]
            resultados.append({
                "modulo": modulo["titulo"],
                "licao": licao["titulo"],
                "pergunta": licao["pergunta"],
                "resposta_usuario": resposta or "Sem resposta",
                "resposta_correta": licao["resposta"],
                "correta": correta
            })

        total = len(resultados)
        acertos = sum(1 for item in resultados if item["correta"])
        percentual = int((acertos / total) * 100) if total else 0
        resultado = {
            "acertos": acertos,
            "total": total,
            "percentual": percentual
        }

        conn = conectar()
        conn.execute(
            """
            INSERT INTO simulados_usuario (usuario_id, acertos, total, percentual, criado_em)
            VALUES (?, ?, ?, ?, ?)
            """,
            (usuario["id"], acertos, total, percentual, datetime.now().isoformat(timespec="seconds"))
        )
        registrar_atividade(conn, usuario["id"])
        conn.commit()
        conn.close()
        conceder_conquistas(usuario["id"])
        criar_backup_progresso(usuario["id"])

    questoes = montar_questoes_simulado(usuario["id"])
    return render_template(
        "app/simulado.html",
        questoes=questoes,
        resultado=resultado,
        resultados=resultados
    )


@app.route("/backup-progresso")
def baixar_backup_progresso():
    usuario = usuario_logado()
    if not usuario:
        return redirect(url_for("login"))

    backup = criar_backup_progresso(usuario["id"])
    if not backup or not os.path.exists(backup["caminho"]):
        return render_template("shared/erro.html", mensagem="Não foi possível gerar o backup agora.")

    nome_arquivo = f"backup_progresso_{usuario['id']}_{date.today()}.json"
    return send_file(backup["caminho"], as_attachment=True, download_name=nome_arquivo)


@app.route("/modulos")
def modulos():
    usuario = usuario_logado()
    if not usuario:
        return redirect(url_for("login"))

    modulos_view = []
    for modulo in MODULOS:
        texto_busca = " ".join(
            [modulo["titulo"], modulo["descricao"]] +
            [licao["titulo"] for licao in modulo["licoes"]]
        )
        progresso = progresso_modulo(usuario["id"], modulo)
        liberado = modulo_liberado(usuario["id"], modulo["id"])
        modulos_view.append({
            **modulo,
            "progresso": progresso,
            "liberado": liberado,
            "busca": normalizar_texto(texto_busca),
            "estrelas": 3 if progresso == 100 else 2 if progresso >= 67 else 1 if progresso > 0 else 0,
            "estado": "concluido" if progresso == 100 else "atual" if liberado else "bloqueado",
        })

    return render_template(
        "learning/modulos.html",
        modulos=modulos_view,
        proxima_licao=proxima_licao_usuario(usuario["id"]),
        nivel_jogo=estado_nivel(usuario["xp"]),
    )


def registrar_historico_codigo(
    conn,
    usuario_id,
    codigo,
    entrada,
    saida,
    build_log,
    contexto="livre",
    licao_id=None,
    modulo_id=None,
    aprovado=False,
    origem="",
):
    conn.execute(
        """
        INSERT INTO compilador_historico
            (usuario_id, codigo, entrada, saida, build_log, criado_em,
             contexto, licao_id, modulo_id, aprovado, origem)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            usuario_id,
            codigo,
            entrada,
            saida,
            build_log,
            datetime.now().isoformat(timespec="seconds"),
            contexto,
            licao_id,
            modulo_id,
            1 if aprovado else 0,
            origem,
        ),
    )
    conn.execute(
        """
        DELETE FROM compilador_historico
        WHERE usuario_id = ? AND id NOT IN (
            SELECT id FROM compilador_historico
            WHERE usuario_id = ? ORDER BY id DESC LIMIT 100
        )
        """,
        (usuario_id, usuario_id),
    )



@app.route("/compilador")
def compilador():
    usuario = usuario_logado()
    if not usuario:
        return redirect(url_for("login"))

    licao_id = request.args.get("licao_id", type=int)
    codigo_inicial = '#include <stdio.h>\n\nint main() {\n    // escreva seu código aqui\n\n    return 0;\n}'
    titulo = "Compilador Online"

    if licao_id:
        modulo, licao = encontrar_licao(licao_id)
        if licao:
            codigo_inicial = licao.get("codigo_minimo", licao["codigo"])
            titulo = f"Compilador - {licao['titulo']}"

    conn = conectar()
    historico = conn.execute(
        "SELECT * FROM compilador_historico WHERE usuario_id = ? ORDER BY id DESC LIMIT 5",
        (usuario["id"],)
    ).fetchall()
    conn.close()

    return render_template(
        "compiler/compilador.html",
        codigo_inicial=codigo_inicial,
        titulo=titulo,
        historico=historico
    )


@app.route("/historico-codigos")
def historico_codigos():
    usuario = usuario_logado()
    if not usuario:
        return redirect(url_for("login"))

    contexto = request.args.get("contexto", "todos")
    contextos = {"todos", "livre", "licao", "diario"}
    if contexto not in contextos:
        contexto = "todos"

    conn = conectar()
    if contexto == "todos":
        registros = conn.execute(
            "SELECT * FROM compilador_historico WHERE usuario_id = ? ORDER BY id DESC LIMIT 100",
            (usuario["id"],),
        ).fetchall()
    else:
        registros = conn.execute(
            """
            SELECT * FROM compilador_historico
            WHERE usuario_id = ? AND contexto = ? ORDER BY id DESC LIMIT 100
            """,
            (usuario["id"], contexto),
        ).fetchall()
    resumo = conn.execute(
        """
        SELECT COUNT(*) AS total,
               SUM(CASE WHEN aprovado = 1 THEN 1 ELSE 0 END) AS aprovados
        FROM compilador_historico WHERE usuario_id = ?
        """,
        (usuario["id"],),
    ).fetchone()
    conn.close()

    itens = []
    for registro in registros:
        modulo, licao = encontrar_licao(registro["licao_id"]) if registro["licao_id"] else (None, None)
        itens.append({
            "registro": registro,
            "titulo": licao["titulo"] if licao else "Prática livre",
            "modulo": modulo["titulo"] if modulo else "Laboratório",
        })

    return render_template(
        "compiler/historico.html",
        itens=itens,
        contexto=contexto,
        total=resumo["total"] or 0,
        aprovados=resumo["aprovados"] or 0,
    )


@app.route("/api/compilador/executar", methods=["POST"])
def api_compilador_executar():
    usuario = usuario_logado()
    if not usuario:
        return jsonify({"ok": False, "build": "Usuário não logado.", "saida": ""}), 401
    if not compilador_seguro.permitir_execucao(usuario["id"]):
        return jsonify({
            "ok": False,
            "build": "Muitas compilações em pouco tempo. Aguarde um minuto.",
            "saida": "",
        }), 429

    dados = request.get_json(silent=True) or {}
    codigo = dados.get("codigo", "")
    entrada = dados.get("entrada", "")

    resultado = executar_compilador_online(codigo, entrada)

    conn = conectar()
    registrar_historico_codigo(
        conn,
        usuario["id"],
        codigo,
        entrada,
        resultado.get("saida", ""),
        resultado.get("build", ""),
        contexto="livre",
        aprovado=resultado.get("ok", False),
        origem=resultado.get("origem", ""),
    )
    if resultado.get("ok"):
        registrar_atividade(conn, usuario["id"])
    conn.commit()
    conn.close()

    return jsonify(resultado)


@app.route("/estudar/<int:modulo_id>")
def estudar(modulo_id):
    usuario = usuario_logado()
    if not usuario:
        return redirect(url_for("login"))

    if not modulo_acessivel(usuario["id"], modulo_id):
        return redirect(url_for("modulos"))

    modulo = next((m for m in MODULOS if m["id"] == modulo_id), None)
    if not modulo:
        return redirect(url_for("modulos"))

    licao_id = request.args.get("licao", type=int)
    if licao_id:
        licao = next((l for l in modulo["licoes"] if l["id"] == licao_id), modulo["licoes"][0])
    else:
        licao = modulo["licoes"][0]

    conn = conectar()
    registros = conn.execute(
        "SELECT * FROM progresso WHERE usuario_id = ? AND modulo_id = ?",
        (usuario["id"], modulo_id)
    ).fetchall()

    registro_licao = conn.execute(
        "SELECT * FROM progresso WHERE usuario_id = ? AND licao_id = ?",
        (usuario["id"], licao["id"])
    ).fetchone()

    favoritos_ids = {
        linha["licao_id"]
        for linha in conn.execute(
            "SELECT licao_id FROM favoritos_usuario WHERE usuario_id = ?",
            (usuario["id"],),
        ).fetchall()
    }

    conn.close()

    concluidas_ids = [r["licao_id"] for r in registros if r["concluida"] == 1]

    codigo_padrao = licao.get("codigo_minimo", licao["codigo"])
    codigo_salvo = registro_licao["codigo_usuario"] if registro_licao and "codigo_usuario" in registro_licao.keys() and registro_licao["codigo_usuario"] else codigo_padrao
    saida_salva = registro_licao["saida_codigo"] if registro_licao and "saida_codigo" in registro_licao.keys() and registro_licao["saida_codigo"] else "A saída do compilador aparecerá aqui."
    quiz_correto = int(registro_licao["quiz_correto"]) if registro_licao and "quiz_correto" in registro_licao.keys() and registro_licao["quiz_correto"] is not None else 0
    resposta_teorica = registro_licao["resposta_teorica"] if registro_licao and "resposta_teorica" in registro_licao.keys() and registro_licao["resposta_teorica"] else ""
    estado_teorico = preparar_desafios_teoricos_view(licao, resposta_teorica, quiz_correto)

    return render_template(
        "learning/estudar.html",
        modulo=modulo,
        licao=licao,
        concluidas_ids=concluidas_ids,
        codigo_salvo=codigo_salvo,
        saida_salva=saida_salva,
        resposta_teorica=resposta_teorica,
        quiz_correto=quiz_correto,
        desafios_teoricos=estado_teorico["desafios"],
        desafios_teoricos_corretos=estado_teorico["corretos"],
        total_desafios_teoricos=estado_teorico["total"],
        desafios_teoricos_concluidos=estado_teorico["todos_corretos"],
        favoritos_ids=favoritos_ids,
        favorita=licao["id"] in favoritos_ids,
    )



@app.route("/exercicio/<int:licao_id>")
def exercicio(licao_id):
    usuario = usuario_logado()
    if not usuario:
        return redirect(url_for("login"))

    modulo, licao = encontrar_licao(licao_id)
    if not licao:
        return redirect(url_for("modulos"))

    if not modulo_acessivel(usuario["id"], modulo["id"]):
        return redirect(url_for("modulos"))

    if not licao.get("pratica_codigo", True):
        return redirect(url_for("estudar", modulo_id=modulo["id"], licao=licao_id))

    conn = conectar()
    registro = conn.execute(
        "SELECT * FROM progresso WHERE usuario_id = ? AND licao_id = ?",
        (usuario["id"], licao_id)
    ).fetchone()
    conn.close()

    codigo_padrao = licao.get("codigo_minimo", "#include <stdio.h>\n\nint main() {\n    return 0;\n}")
    codigo_salvo = registro["codigo_usuario"] if registro and registro["codigo_usuario"] else codigo_padrao
    saida_salva = registro["saida_codigo"] if registro and "saida_codigo" in registro.keys() and registro["saida_codigo"] else "A saída do compilador aparecerá aqui."
    entrada_salva = registro["entrada_codigo"] if registro and "entrada_codigo" in registro.keys() and registro["entrada_codigo"] else ""
    codigo_validado = registro["codigo_validado"] if registro and "codigo_validado" in registro.keys() else 0
    feedback_codigo = registro["feedback_codigo"] if registro and "feedback_codigo" in registro.keys() and registro["feedback_codigo"] else ""
    return render_template(
        "learning/exercicio.html",
        modulo=modulo,
        licao=licao,
        codigo_salvo=codigo_salvo,
        saida_salva=saida_salva,
        entrada_salva=entrada_salva,
        codigo_validado=codigo_validado,
        feedback_codigo=feedback_codigo
    )




@app.route("/api/exercicio/salvar-rascunho", methods=["POST"])
def salvar_rascunho_exercicio():
    usuario = usuario_logado()
    if not usuario:
        return jsonify({"ok": False, "mensagem": "Usuário não logado."}), 401

    dados = request.get_json(silent=True) or {}
    licao_id = dados.get("licao_id")
    codigo = dados.get("codigo", "")
    entrada = dados.get("entrada", "")

    modulo, licao, erro = licao_acessivel_para_usuario(
        usuario["id"], licao_id, exigir_pratica=True
    )
    if erro:
        mensagem, status = erro
        return jsonify({"ok": False, "mensagem": mensagem}), status

    licao_id = licao["id"]

    conn = conectar()
    conn.execute(
        """
        INSERT INTO progresso (usuario_id, licao_id, modulo_id, codigo_usuario, entrada_codigo, atualizado_em)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(usuario_id, licao_id)
        DO UPDATE SET codigo_validado = CASE
                          WHEN COALESCE(progresso.codigo_usuario, '') = COALESCE(excluded.codigo_usuario, '')
                           AND COALESCE(progresso.entrada_codigo, '') = COALESCE(excluded.entrada_codigo, '')
                          THEN progresso.codigo_validado ELSE 0 END,
                      codigo_enviado = CASE
                          WHEN COALESCE(progresso.codigo_usuario, '') = COALESCE(excluded.codigo_usuario, '')
                           AND COALESCE(progresso.entrada_codigo, '') = COALESCE(excluded.entrada_codigo, '')
                          THEN progresso.codigo_enviado ELSE 0 END,
                      feedback_codigo = CASE
                          WHEN COALESCE(progresso.codigo_usuario, '') = COALESCE(excluded.codigo_usuario, '')
                           AND COALESCE(progresso.entrada_codigo, '') = COALESCE(excluded.entrada_codigo, '')
                          THEN progresso.feedback_codigo ELSE NULL END,
                      saida_codigo = CASE
                          WHEN COALESCE(progresso.codigo_usuario, '') = COALESCE(excluded.codigo_usuario, '')
                           AND COALESCE(progresso.entrada_codigo, '') = COALESCE(excluded.entrada_codigo, '')
                          THEN progresso.saida_codigo ELSE NULL END,
                      codigo_usuario = excluded.codigo_usuario,
                      entrada_codigo = excluded.entrada_codigo,
                      atualizado_em = excluded.atualizado_em
        """,
        (usuario["id"], licao_id, modulo["id"], codigo, entrada, str(date.today()))
    )
    conn.commit()
    conn.close()
    return jsonify({"ok": True, "mensagem": "Rascunho salvo."})


@app.route("/api/desafio/salvar-rascunho", methods=["POST"])
def salvar_rascunho_desafio():
    usuario = usuario_logado()
    if not usuario:
        return jsonify({"ok": False, "mensagem": "Usuário não logado."}), 401

    dados = request.get_json() or {}
    codigo = dados.get("codigo", "")
    entrada = dados.get("entrada", "")
    hoje = str(date.today())
    desafio = desafio_do_dia(hoje, usuario["id"])
    if not desafio:
        return jsonify({
            "ok": False,
            "mensagem": "Conclua o módulo 1 para desbloquear os desafios diários."
        }), 403

    conn = conectar()
    conn.execute(
        """
        INSERT INTO desafios_diarios (usuario_id, data, desafio_id, codigo_usuario, entrada_codigo, concluido)
        VALUES (?, ?, ?, ?, ?, 0)
        ON CONFLICT(usuario_id, data)
        DO UPDATE SET codigo_validado = CASE
                          WHEN COALESCE(desafios_diarios.codigo_usuario, '') = COALESCE(excluded.codigo_usuario, '')
                           AND COALESCE(desafios_diarios.entrada_codigo, '') = COALESCE(excluded.entrada_codigo, '')
                           AND COALESCE(desafios_diarios.desafio_id, '') = COALESCE(excluded.desafio_id, '')
                          THEN desafios_diarios.codigo_validado ELSE 0 END,
                      feedback_codigo = CASE
                          WHEN COALESCE(desafios_diarios.codigo_usuario, '') = COALESCE(excluded.codigo_usuario, '')
                           AND COALESCE(desafios_diarios.entrada_codigo, '') = COALESCE(excluded.entrada_codigo, '')
                           AND COALESCE(desafios_diarios.desafio_id, '') = COALESCE(excluded.desafio_id, '')
                          THEN desafios_diarios.feedback_codigo ELSE NULL END,
                      saida_codigo = CASE
                          WHEN COALESCE(desafios_diarios.codigo_usuario, '') = COALESCE(excluded.codigo_usuario, '')
                           AND COALESCE(desafios_diarios.entrada_codigo, '') = COALESCE(excluded.entrada_codigo, '')
                           AND COALESCE(desafios_diarios.desafio_id, '') = COALESCE(excluded.desafio_id, '')
                          THEN desafios_diarios.saida_codigo ELSE NULL END,
                      desafio_id = excluded.desafio_id,
                      codigo_usuario = excluded.codigo_usuario,
                      entrada_codigo = excluded.entrada_codigo
        """,
        (usuario["id"], hoje, desafio["id"], codigo, entrada)
    )
    conn.commit()
    conn.close()
    return jsonify({"ok": True, "mensagem": "Rascunho salvo."})


@app.route("/api/exercicio/preparar-terminal", methods=["POST"])
def api_exercicio_preparar_terminal():
    usuario = usuario_logado()
    if not usuario:
        return jsonify({"ok": False, "build": "Usuário não logado.", "prompt": ""}), 401
    if not compilador_seguro.permitir_execucao(usuario["id"]):
        return jsonify({"ok": False, "build": "Aguarde antes de compilar novamente.", "prompt": ""}), 429

    dados = request.get_json()
    codigo = dados.get("codigo", "")

    resultado_build = compilar_codigo_c(codigo)
    prompt = detectar_prompt_entrada(codigo)

    return jsonify({
        "ok": resultado_build.get("ok", False),
        "build": resultado_build.get("build", ""),
        "prompt": prompt
    })


@app.route("/api/exercicio/compilar", methods=["POST"])
def api_exercicio_compilar():
    usuario = usuario_logado()
    if not usuario:
        return jsonify({"ok": False, "build": "Usuário não logado.", "saida": ""}), 401
    if not compilador_seguro.permitir_execucao(usuario["id"]):
        return jsonify({"ok": False, "build": "Aguarde antes de compilar novamente.", "saida": ""}), 429

    dados = request.get_json(silent=True) or {}
    licao_id = dados.get("licao_id")
    codigo = dados.get("codigo", "")
    entrada = dados.get("entrada", "")

    modulo, licao, erro = licao_acessivel_para_usuario(
        usuario["id"], licao_id, exigir_pratica=True
    )
    if erro:
        mensagem, status = erro
        return jsonify({"ok": False, "build": mensagem, "saida": ""}), status

    licao_id = licao["id"]

    resultado = executar_compilador_online(codigo, entrada)
    validacao = avaliar_codigo_automaticamente(codigo, resultado, licao.get("correcao"))
    resultado["correcao"] = validacao
    resultado["codigo_validado"] = 1 if validacao["ok"] else 0

    conn = conectar()
    conn.execute(
        """
        INSERT INTO progresso (usuario_id, licao_id, modulo_id, codigo_usuario, saida_codigo, entrada_codigo, codigo_enviado, codigo_validado, feedback_codigo, atualizado_em)
        VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?)
        ON CONFLICT(usuario_id, licao_id)
        DO UPDATE SET codigo_usuario = excluded.codigo_usuario,
                      saida_codigo = excluded.saida_codigo,
                      entrada_codigo = excluded.entrada_codigo,
                      codigo_enviado = 1,
                      codigo_validado = excluded.codigo_validado,
                      feedback_codigo = excluded.feedback_codigo,
                      atualizado_em = excluded.atualizado_em
        """,
        (usuario["id"], licao_id, modulo["id"], codigo, resultado.get("saida", ""), entrada, resultado["codigo_validado"], validacao["mensagem"], str(date.today()))
    )
    registrar_historico_codigo(
        conn,
        usuario["id"],
        codigo,
        entrada,
        resultado.get("saida", ""),
        resultado.get("build", ""),
        contexto="licao",
        licao_id=licao_id,
        modulo_id=modulo["id"],
        aprovado=validacao["ok"],
        origem=resultado.get("origem", ""),
    )
    conn.commit()
    conn.close()
    criar_backup_progresso(usuario["id"])

    return jsonify(resultado)


@app.route("/desafio-diario")
def desafio_diario():
    usuario = usuario_logado()
    if not usuario:
        return redirect(url_for("login"))

    hoje = str(date.today())
    desafios_disponiveis, modulo_maximo_diario = desafios_diarios_do_usuario(usuario["id"])

    if not desafios_disponiveis:
        return render_template(
            "learning/desafio_diario.html",
            desafio=None,
            codigo="",
            saida="A saída do desafio aparecerá aqui.",
            entrada="",
            concluido=0,
            codigo_validado=0,
            feedback_codigo="",
            desafio_bloqueado=True,
            modulo_maximo_diario=modulo_maximo_diario,
            total_desafios_disponiveis=0
        )

    conn = conectar()
    registro = conn.execute(
        "SELECT * FROM desafios_diarios WHERE usuario_id = ? AND data = ?",
        (usuario["id"], hoje)
    ).fetchone()
    conn.close()

    desafio = None
    if registro and "desafio_id" in registro.keys() and registro["desafio_id"]:
        desafio = desafio_diario_por_id(desafios_disponiveis, registro["desafio_id"])

    if not desafio:
        desafio = escolher_desafio_do_dia(desafios_disponiveis, hoje)

    registro_mesmo_desafio = registro and "desafio_id" in registro.keys() and registro["desafio_id"] == desafio["id"]
    codigo = registro["codigo_usuario"] if registro_mesmo_desafio and registro["codigo_usuario"] else desafio["codigo_inicial"]
    saida = registro["saida_codigo"] if registro_mesmo_desafio and registro["saida_codigo"] else "A saída do desafio aparecerá aqui."
    entrada = registro["entrada_codigo"] if registro_mesmo_desafio and "entrada_codigo" in registro.keys() and registro["entrada_codigo"] else ""
    concluido = registro["concluido"] if registro_mesmo_desafio else 0
    codigo_validado = registro["codigo_validado"] if registro_mesmo_desafio and "codigo_validado" in registro.keys() else 0
    feedback_codigo = registro["feedback_codigo"] if registro_mesmo_desafio and "feedback_codigo" in registro.keys() and registro["feedback_codigo"] else ""
    return render_template(
        "learning/desafio_diario.html",
        desafio=desafio,
        codigo=codigo,
        saida=saida,
        entrada=entrada,
        concluido=concluido,
        codigo_validado=codigo_validado,
        feedback_codigo=feedback_codigo,
        desafio_bloqueado=False,
        modulo_maximo_diario=modulo_maximo_diario,
        total_desafios_disponiveis=len(desafios_disponiveis)
    )


@app.route("/verificar", methods=["POST"])
def verificar():
    usuario = usuario_logado()
    if not usuario:
        return jsonify({"correta": False, "mensagem": "Usuário não logado."}), 401

    dados = request.get_json(silent=True) or {}
    licao_id = dados.get("licao_id")
    resposta = str(dados.get("resposta", ""))
    desafio_id = str(dados.get("desafio_id", "conceito"))

    modulo, licao, erro = licao_acessivel_para_usuario(usuario["id"], licao_id)
    if erro:
        mensagem, status = erro
        return jsonify({"correta": False, "mensagem": mensagem}), status

    licao_id = licao["id"]

    conn = None
    try:
        conn = conectar()
        registro = conn.execute(
            "SELECT resposta_teorica, quiz_correto FROM progresso WHERE usuario_id = ? AND licao_id = ?",
            (usuario["id"], licao_id)
        ).fetchone()

        valor_atual = registro["resposta_teorica"] if registro and "resposta_teorica" in registro.keys() and registro["resposta_teorica"] else ""
        quiz_atual = registro["quiz_correto"] if registro and "quiz_correto" in registro.keys() and registro["quiz_correto"] is not None else 0
        resultado_teorico = atualizar_resposta_teorica(licao, valor_atual, desafio_id, resposta, quiz_atual)

        if not resultado_teorico:
            conn.close()
            return jsonify({"correta": False, "mensagem": "Desafio teórico não encontrado."}), 404

        if resultado_teorico.get("erro"):
            conn.close()
            return jsonify({"correta": False, "mensagem": resultado_teorico["erro"]}), 400

        conn.execute(
            """
            INSERT INTO progresso (usuario_id, licao_id, modulo_id, quiz_correto, quiz_respondido, resposta_teorica, atualizado_em)
            VALUES (?, ?, ?, ?, 1, ?, ?)
            ON CONFLICT(usuario_id, licao_id)
            DO UPDATE SET quiz_correto = excluded.quiz_correto,
                          quiz_respondido = 1,
                          resposta_teorica = excluded.resposta_teorica,
                          atualizado_em = excluded.atualizado_em
            """,
            (
                usuario["id"],
                licao_id,
                modulo["id"],
                1 if resultado_teorico["todos_corretos"] else 0,
                resultado_teorico["resposta_json"],
                str(date.today())
            )
        )
        if resultado_teorico["novo_acerto"]:
            registrar_atividade(conn, usuario["id"], quizzes=1)
        conn.commit()
        conn.close()
        if resultado_teorico["novo_acerto"]:
            conceder_conquistas(usuario["id"])
        criar_backup_progresso(usuario["id"])
    except Exception as erro:
        if conn is not None:
            conn.rollback()
            conn.close()
        return jsonify({
            "correta": False,
            "mensagem": f"Erro ao salvar resposta: {erro}"
        }), 500

    correta = resultado_teorico["correta"]
    if resultado_teorico["todos_corretos"] and not licao.get("pratica_codigo", True):
        mensagem = "Todos os desafios teóricos estão corretos. Agora você já pode concluir a lição."
    elif resultado_teorico["todos_corretos"]:
        mensagem = "Todos os desafios teóricos estão corretos. Agora faça o exercício de código para concluir."
    elif correta:
        mensagem = f"Resposta salva: correta. Falta acertar {resultado_teorico['total'] - resultado_teorico['corretos']} desafio(s)."
    else:
        mensagem = "Resposta salva: incorreta. Revise o conteúdo e tente novamente."

    return jsonify({
        "correta": correta,
        "resposta_salva": True,
        "mensagem": mensagem,
        "explicacao": resultado_teorico["explicacao"],
        "corretos": resultado_teorico["corretos"],
        "total": resultado_teorico["total"],
        "todos_corretos": resultado_teorico["todos_corretos"]
    })


@app.route("/compilar-codigo", methods=["POST"])
def compilar_codigo():
    usuario = usuario_logado()
    if not usuario:
        return jsonify({"ok": False, "build": "Usuário não logado.", "saida": ""}), 401
    if not compilador_seguro.permitir_execucao(usuario["id"]):
        return jsonify({"ok": False, "build": "Aguarde antes de compilar novamente.", "saida": ""}), 429

    dados = request.get_json(silent=True) or {}
    codigo = dados.get("codigo", "")

    resultado = compilar_codigo_c(codigo)
    return jsonify(resultado)


@app.route("/executar-codigo", methods=["POST"])
def executar_codigo():
    usuario = usuario_logado()
    if not usuario:
        return jsonify({"ok": False, "saida": "Usuário não logado."}), 401
    if not compilador_seguro.permitir_execucao(usuario["id"]):
        return jsonify({"ok": False, "build": "Aguarde antes de compilar novamente.", "saida": ""}), 429

    dados = request.get_json(silent=True) or {}
    codigo = dados.get("codigo", "")
    entrada = dados.get("entrada", "")
    licao_id = dados.get("licao_id")
    tipo = dados.get("tipo", "licao")

    modulo = None
    licao = None
    desafio = None

    if tipo == "licao":
        modulo, licao, erro = licao_acessivel_para_usuario(
            usuario["id"], licao_id, exigir_pratica=True
        )
        if erro:
            mensagem, status = erro
            return jsonify({"ok": False, "saida": mensagem, "build": ""}), status
        licao_id = licao["id"]
    elif tipo == "diario":
        desafio = desafio_do_dia(str(date.today()), usuario["id"])
        if not desafio:
            return jsonify({
                "ok": False,
                "saida": "Conclua o módulo 1 para desbloquear os desafios diários.",
                "build": ""
            }), 403
    elif tipo not in {"livre", "compilador"}:
        return jsonify({"ok": False, "saida": "Tipo de execução inválido.", "build": ""}), 400

    resultado = executar_compilador_online(codigo, entrada)

    if tipo == "licao":
        validacao = avaliar_codigo_automaticamente(codigo, resultado, licao.get("correcao"))
        resultado["correcao"] = validacao
        resultado["codigo_validado"] = 1 if validacao["ok"] else 0
        try:
            conn = conectar()
            conn.execute(
                """
                INSERT INTO progresso (usuario_id, licao_id, modulo_id, codigo_usuario, saida_codigo, entrada_codigo, codigo_enviado, codigo_validado, feedback_codigo, atualizado_em)
                VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?)
                ON CONFLICT(usuario_id, licao_id)
                DO UPDATE SET codigo_usuario = excluded.codigo_usuario,
                              saida_codigo = excluded.saida_codigo,
                              entrada_codigo = excluded.entrada_codigo,
                              codigo_enviado = 1,
                              codigo_validado = excluded.codigo_validado,
                              feedback_codigo = excluded.feedback_codigo,
                              atualizado_em = excluded.atualizado_em
                """,
                (usuario["id"], licao_id, modulo["id"], codigo, resultado.get("saida", ""), entrada, resultado["codigo_validado"], validacao["mensagem"], str(date.today()))
            )
            registrar_historico_codigo(
                conn, usuario["id"], codigo, entrada,
                resultado.get("saida", ""), resultado.get("build", ""),
                contexto="licao", licao_id=licao_id, modulo_id=modulo["id"],
                aprovado=validacao["ok"], origem=resultado.get("origem", ""),
            )
            conn.commit()
            conn.close()
            criar_backup_progresso(usuario["id"])
        except Exception as erro:
            return jsonify({
                "ok": False,
                "saida": f"Erro ao salvar código no banco: {erro}"
            }), 500

    if tipo == "diario":
        hoje = str(date.today())
        validacao = avaliar_codigo_automaticamente(codigo, resultado, desafio.get("correcao"))
        resultado["correcao"] = validacao
        resultado["codigo_validado"] = 1 if validacao["ok"] else 0
        conn = conectar()
        conn.execute(
            """
            INSERT INTO desafios_diarios (usuario_id, data, desafio_id, codigo_usuario, saida_codigo, entrada_codigo, codigo_validado, feedback_codigo, concluido)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
            ON CONFLICT(usuario_id, data)
            DO UPDATE SET codigo_usuario = excluded.codigo_usuario,
                          saida_codigo = excluded.saida_codigo,
                          entrada_codigo = excluded.entrada_codigo,
                          desafio_id = excluded.desafio_id,
                          codigo_validado = excluded.codigo_validado,
                          feedback_codigo = excluded.feedback_codigo
            """,
            (usuario["id"], hoje, desafio["id"], codigo, resultado.get("saida", ""), entrada, resultado["codigo_validado"], validacao["mensagem"])
        )
        registrar_historico_codigo(
            conn, usuario["id"], codigo, entrada,
            resultado.get("saida", ""), resultado.get("build", ""),
            contexto="diario", licao_id=desafio.get("licao_id"),
            modulo_id=desafio.get("modulo_id"), aprovado=validacao["ok"],
            origem=resultado.get("origem", ""),
        )
        conn.commit()
        conn.close()
        criar_backup_progresso(usuario["id"])

    if tipo in {"livre", "compilador"}:
        conn = conectar()
        registrar_historico_codigo(
            conn, usuario["id"], codigo, entrada,
            resultado.get("saida", ""), resultado.get("build", ""),
            contexto="livre", aprovado=resultado.get("ok", False),
            origem=resultado.get("origem", ""),
        )
        conn.commit()
        conn.close()

    return jsonify(resultado)


@app.route("/concluir/<int:licao_id>", methods=["POST"])
def concluir(licao_id):
    usuario = usuario_logado()
    if not usuario:
        return jsonify({"erro": "Usuário não logado"}), 401

    modulo, licao, erro = licao_acessivel_para_usuario(usuario["id"], licao_id)
    if erro:
        mensagem, status = erro
        return jsonify({"ok": False, "mensagem": mensagem}), status

    conn = conectar()
    registro = conn.execute(
        "SELECT * FROM progresso WHERE usuario_id = ? AND licao_id = ?",
        (usuario["id"], licao_id)
    ).fetchone()

    if not registro or registro["quiz_correto"] != 1:
        conn.close()
        return jsonify({"ok": False, "mensagem": "Responda corretamente todos os desafios teóricos antes de concluir."})

    exige_codigo = licao.get("pratica_codigo", True)

    if exige_codigo:
        if not registro["codigo_usuario"]:
            conn.close()
            return jsonify({"ok": False, "mensagem": "Faça e execute o exercício de código antes de concluir."})

        if "codigo_validado" in registro.keys() and registro["codigo_validado"] != 1:
            mensagem = registro["feedback_codigo"] or "Execute o código e passe na correção automática antes de concluir."
            conn.close()
            return jsonify({"ok": False, "mensagem": mensagem})

    ja_concluida = registro["concluida"] == 1

    conn.execute(
        "UPDATE progresso SET concluida = 1, codigo_enviado = ?, atualizado_em = ? WHERE usuario_id = ? AND licao_id = ?",
        (1 if exige_codigo else 0, str(date.today()), usuario["id"], licao_id)
    )

    if not ja_concluida:
        conn.execute("UPDATE usuarios SET xp = xp + 50 WHERE id = ?", (usuario["id"],))
        registrar_atividade(conn, usuario["id"], licoes=1, xp_ganho=50)
        conn.execute(
            """
            INSERT OR IGNORE INTO revisoes_usuario
                (usuario_id, licao_id, nivel, proxima_revisao, acertos, erros)
            VALUES (?, ?, 0, ?, 0, 0)
            """,
            (usuario["id"], licao_id, (date.today() + timedelta(days=1)).isoformat()),
        )

    conn.commit()
    conn.close()

    atualizar_nivel(usuario["id"])
    conceder_conquistas(usuario["id"])
    criar_backup_progresso(usuario["id"])

    return jsonify({"ok": True, "mensagem": "Lição concluída! +50 XP"})


@app.route("/concluir-desafio-diario", methods=["POST"])
def concluir_desafio_diario():
    usuario = usuario_logado()
    if not usuario:
        return jsonify({"ok": False, "mensagem": "Usuário não logado."}), 401

    desafios_disponiveis, _ = desafios_diarios_do_usuario(usuario["id"])
    if not desafios_disponiveis:
        return jsonify({
            "ok": False,
            "mensagem": "Conclua o módulo 1 para desbloquear os desafios diários."
        }), 403

    hoje = str(date.today())
    conn = conectar()
    registro = conn.execute(
        "SELECT * FROM desafios_diarios WHERE usuario_id = ? AND data = ?",
        (usuario["id"], hoje)
    ).fetchone()

    if not registro or not registro["codigo_usuario"] or not desafio_diario_por_id(desafios_disponiveis, registro["desafio_id"]):
        conn.close()
        return jsonify({"ok": False, "mensagem": "Execute um código antes de concluir o desafio diário."})

    if "codigo_validado" in registro.keys() and registro["codigo_validado"] != 1:
        mensagem = registro["feedback_codigo"] or "Passe na correção automática antes de concluir o desafio diário."
        conn.close()
        return jsonify({"ok": False, "mensagem": mensagem})

    if registro["concluido"] != 1:
        conn.execute(
            "UPDATE desafios_diarios SET concluido = 1 WHERE usuario_id = ? AND data = ?",
            (usuario["id"], hoje)
        )
        conn.execute("UPDATE usuarios SET xp = xp + 30 WHERE id = ?", (usuario["id"],))
        registrar_atividade(conn, usuario["id"], desafios=1, xp_ganho=30)

    conn.commit()
    conn.close()

    atualizar_nivel(usuario["id"])
    conceder_conquistas(usuario["id"])
    criar_backup_progresso(usuario["id"])

    return jsonify({"ok": True, "mensagem": "Desafio diário concluído! +30 XP"})



# -------------------------------
# COMPILADOR REAL INTERATIVO
# -------------------------------

PROCESSOS_TERMINAL = {}
TERMINAL_POR_USUARIO = {}
PROCESSOS_TERMINAL_LOCK = threading.RLock()


def salvar_codigo_execucao(usuario_id, licao_id, codigo, entrada, saida, execucao_ok=True):
    modulo, licao, erro = licao_acessivel_para_usuario(
        usuario_id, licao_id, exigir_pratica=True
    )
    if erro:
        mensagem, _ = erro
        return {"ok": False, "mensagem": mensagem}

    licao_id = licao["id"]

    validacao = avaliar_codigo_automaticamente(
        codigo,
        {"ok": bool(execucao_ok), "saida": saida, "build": "Build finished successfully."},
        licao.get("correcao")
    )

    conn = conectar()
    conn.execute(
        """
        INSERT INTO progresso (usuario_id, licao_id, modulo_id, codigo_usuario, saida_codigo, entrada_codigo, codigo_enviado, codigo_validado, feedback_codigo, atualizado_em)
        VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?)
        ON CONFLICT(usuario_id, licao_id)
        DO UPDATE SET codigo_usuario = excluded.codigo_usuario,
                      saida_codigo = excluded.saida_codigo,
                      entrada_codigo = excluded.entrada_codigo,
                      codigo_enviado = 1,
                      codigo_validado = excluded.codigo_validado,
                      feedback_codigo = excluded.feedback_codigo,
                      atualizado_em = excluded.atualizado_em
        """,
        (usuario_id, licao_id, modulo["id"], codigo, saida, entrada, 1 if validacao["ok"] else 0, validacao["mensagem"], str(date.today()))
    )
    registrar_historico_codigo(
        conn, usuario_id, codigo, entrada, saida,
        "Terminal interativo compilado com GCC.",
        contexto="licao", licao_id=licao_id, modulo_id=modulo["id"],
        aprovado=validacao["ok"], origem="GCC interativo protegido",
    )
    if validacao["ok"]:
        registrar_atividade(conn, usuario_id)
    conn.commit()
    conn.close()
    criar_backup_progresso(usuario_id)
    return validacao


def salvar_desafio_diario_execucao(usuario_id, codigo, entrada, saida, execucao_ok=True):
    hoje = str(date.today())
    desafio = desafio_do_dia(hoje, usuario_id)
    if not desafio:
        return {
            "ok": False,
            "mensagem": "Conclua o módulo 1 para desbloquear os desafios diários."
        }

    validacao = avaliar_codigo_automaticamente(
        codigo,
        {"ok": bool(execucao_ok), "saida": saida, "build": "Build finished successfully."},
        desafio.get("correcao")
    )

    conn = conectar()
    conn.execute(
        """
        INSERT INTO desafios_diarios (usuario_id, data, desafio_id, codigo_usuario, saida_codigo, entrada_codigo, codigo_validado, feedback_codigo, concluido)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
        ON CONFLICT(usuario_id, data)
        DO UPDATE SET desafio_id = excluded.desafio_id,
                      codigo_usuario = excluded.codigo_usuario,
                      saida_codigo = excluded.saida_codigo,
                      entrada_codigo = excluded.entrada_codigo,
                      codigo_validado = excluded.codigo_validado,
                      feedback_codigo = excluded.feedback_codigo
        """,
        (usuario_id, hoje, desafio["id"], codigo, saida, entrada, 1 if validacao["ok"] else 0, validacao["mensagem"])
    )
    registrar_historico_codigo(
        conn, usuario_id, codigo, entrada, saida,
        "Terminal interativo compilado com GCC.",
        contexto="diario", licao_id=desafio.get("licao_id"),
        modulo_id=desafio.get("modulo_id"), aprovado=validacao["ok"],
        origem="GCC interativo protegido",
    )
    if validacao["ok"]:
        registrar_atividade(conn, usuario_id)
    conn.commit()
    conn.close()
    criar_backup_progresso(usuario_id)
    return validacao


def encerrar_processo_socket(sid):
    with PROCESSOS_TERMINAL_LOCK:
        dados = PROCESSOS_TERMINAL.pop(sid, None)
        if dados:
            usuario_id = dados.get("usuario_id")
            if TERMINAL_POR_USUARIO.get(usuario_id) == sid:
                TERMINAL_POR_USUARIO.pop(usuario_id, None)
    if not dados:
        return

    proc = dados.get("proc")
    fd = dados.get("fd")
    temp_dir = dados.get("temp_dir")

    compilador_seguro.encerrar_processo(proc)

    try:
        if fd:
            os.close(fd)
    except Exception:
        pass

    try:
        if temp_dir and os.path.exists(temp_dir):
            shutil.rmtree(temp_dir, ignore_errors=True)
    except Exception:
        pass

    if dados.get("slot_adquirido"):
        dados["slot_adquirido"] = False
        compilador_seguro.liberar_slot()


def leitor_terminal(sid):
    with PROCESSOS_TERMINAL_LOCK:
        dados = PROCESSOS_TERMINAL.get(sid)
    if not dados:
        return

    proc = dados["proc"]
    fd = dados["fd"]
    saida_total = ""
    inicio = time.time()
    motivo_interrupcao = ""
    limite_segundos = compilador_seguro.TEMPO_INTERATIVO
    total_bytes = 0

    def consumir_saida(bloco):
        nonlocal saida_total, total_bytes, motivo_interrupcao
        restante = compilador_seguro.MAX_SAIDA_BYTES - total_bytes
        if restante <= 0:
            motivo_interrupcao = "Limite de saída excedido."
            return False
        trecho = bloco[:restante]
        total_bytes += len(trecho)
        texto = trecho.decode("utf-8", errors="replace")
        saida_total += texto
        socketio.emit("terminal_saida", {"texto": texto}, to=sid)
        if len(bloco) > restante:
            motivo_interrupcao = "Limite de saída excedido."
            return False
        return True

    while True:
        if time.time() - inicio > limite_segundos:
            motivo_interrupcao = "Tempo limite excedido."
            compilador_seguro.encerrar_processo(proc)
            aviso = "\n\nTempo limite excedido.\n"
            saida_total += aviso
            socketio.emit("terminal_saida", {"texto": aviso}, to=sid)
            break

        try:
            pronto, _, _ = select.select([fd], [], [], 0.2)
            if fd in pronto:
                dados_lidos = os.read(fd, 4096)
                if not dados_lidos:
                    if proc.poll() is not None:
                        break
                elif not consumir_saida(dados_lidos):
                    compilador_seguro.encerrar_processo(proc)
                    aviso = "\n\nSaída interrompida: limite atingido.\n"
                    saida_total += aviso
                    socketio.emit("terminal_saida", {"texto": aviso}, to=sid)
                    break
        except OSError:
            if proc.poll() is None:
                motivo_interrupcao = "Erro na leitura do terminal."
                compilador_seguro.encerrar_processo(proc)
            break
        except Exception as erro:
            socketio.emit("terminal_saida", {"texto": f"\nErro no terminal: {erro}\n"}, to=sid)
            motivo_interrupcao = "Erro na leitura do terminal."
            break

        if proc.poll() is not None:
            # O processo pode terminar antes de a tarefa leitora iniciar. Drene o PTY.
            while True:
                try:
                    pronto, _, _ = select.select([fd], [], [], 0)
                    if fd not in pronto:
                        break
                    bloco = os.read(fd, 4096)
                    if not bloco or not consumir_saida(bloco):
                        break
                except OSError:
                    break
            break

    codigo_saida = proc.poll()
    if codigo_saida is None:
        compilador_seguro.encerrar_processo(proc)
        codigo_saida = proc.poll()
    if codigo_saida is None:
        codigo_saida = -1

    execucao_ok = codigo_saida == 0 and not motivo_interrupcao
    fim = (
        "\n\nProcess returned 0 (0x0)\n"
        if execucao_ok
        else f"\n\nProcess returned {codigo_saida}\n"
    )
    saida_total += fim
    socketio.emit("terminal_saida", {"texto": fim}, to=sid)
    socketio.emit("terminal_finalizado", {"codigo": codigo_saida}, to=sid)

    usuario_id = dados.get("usuario_id")
    licao_id = dados.get("licao_id")
    tipo = dados.get("tipo", "licao")
    codigo = dados.get("codigo", "")
    entrada = dados.get("entrada", "")

    if dados.get("slot_adquirido"):
        dados["slot_adquirido"] = False
        compilador_seguro.liberar_slot()

    try:
        validacao = None
        if usuario_id and tipo == "diario":
            validacao = salvar_desafio_diario_execucao(
                usuario_id, codigo, entrada, saida_total, execucao_ok
            )
        elif usuario_id and licao_id:
            validacao = salvar_codigo_execucao(
                usuario_id, licao_id, codigo, entrada, saida_total, execucao_ok
            )

        if validacao:
            socketio.emit("correcao_resultado", validacao, to=sid)
    except Exception:
        socketio.emit("correcao_resultado", {
            "ok": False,
            "mensagem": "A execução terminou, mas não foi possível salvar a correção."
        }, to=sid)
    finally:
        encerrar_processo_socket(sid)


@socketio.on("compilar_real")
def compilar_real(dados):
    usuario_id = session.get("usuario_id")
    if not usuario_id:
        emit("build_log", {"ok": False, "texto": "Usuário não logado."})
        return

    sid = request.sid
    encerrar_processo_socket(sid)

    if not compilador_seguro.permitir_execucao(usuario_id):
        emit("build_log", {
            "ok": False,
            "texto": "Muitas compilações em pouco tempo. Aguarde um minuto."
        })
        return

    dados = dados or {}
    codigo = dados.get("codigo", "")
    licao_id = dados.get("licao_id")
    tipo = dados.get("tipo", "licao")

    if tipo == "licao":
        _, licao, erro = licao_acessivel_para_usuario(
            usuario_id, licao_id, exigir_pratica=True
        )
        if erro:
            mensagem, _ = erro
            emit("build_log", {"ok": False, "texto": mensagem})
            return
        licao_id = licao["id"]
    elif tipo == "diario":
        if not desafio_do_dia(str(date.today()), usuario_id):
            emit("build_log", {
                "ok": False,
                "texto": "Conclua o módulo 1 para desbloquear os desafios diários."
            })
            return
    else:
        emit("build_log", {"ok": False, "texto": "Tipo de execução inválido."})
        return

    erro_validacao = validar_codigo_recebido(codigo)
    if erro_validacao:
        emit("build_log", {"ok": False, "texto": erro_validacao})
        return

    if pty is None or os.name == "nt":
        emit("build_log", {
            "ok": False,
            "texto": "Terminal interativo real disponível no ambiente Linux/Docker. Para Windows local, use o Dockerfile do projeto ou publique no Render."
        })
        return

    with PROCESSOS_TERMINAL_LOCK:
        sid_existente = TERMINAL_POR_USUARIO.get(usuario_id)
        if sid_existente and sid_existente != sid:
            emit("build_log", {
                "ok": False,
                "texto": "Já existe um terminal em execução nesta conta. Feche a outra aba ou aguarde o término."
            })
            return

    if not compilador_seguro.adquirir_slot():
        emit("build_log", {
            "ok": False,
            "texto": "Todos os terminais estão ocupados. Aguarde alguns segundos."
        })
        return

    with PROCESSOS_TERMINAL_LOCK:
        TERMINAL_POR_USUARIO[usuario_id] = sid

    slot_reserva = True
    temp_dir = None
    master_fd = None
    slave_fd = None

    try:
        preparacao = compilador_seguro.preparar_terminal(codigo)
        if not preparacao.get("ok"):
            emit("build_log", {"ok": False, "texto": preparacao.get("build", "Falha ao compilar.")})
            return

        temp_dir = preparacao["temp_dir"]
        arquivo_saida = preparacao["executavel"]

        emit("build_log", {
            "ok": True,
            "texto": preparacao.get("build", "Build finished successfully.")
        })

        master_fd, slave_fd = pty.openpty()
        proc = compilador_seguro.iniciar_terminal(arquivo_saida, temp_dir, slave_fd)

        os.close(slave_fd)
        slave_fd = None

        with PROCESSOS_TERMINAL_LOCK:
            PROCESSOS_TERMINAL[sid] = {
                "proc": proc,
                "fd": master_fd,
                "temp_dir": temp_dir,
                "usuario_id": usuario_id,
                "licao_id": licao_id,
                "tipo": tipo,
                "codigo": codigo,
                "entrada": "",
                "slot_adquirido": True,
            }

        slot_reserva = False
        master_fd = None
        temp_dir = None

        socketio.start_background_task(leitor_terminal, sid)

    except Exception as erro:
        emit("build_log", {
            "ok": False,
            "texto": f"Erro ao compilar: {erro}"
        })
    finally:
        if slave_fd is not None:
            try:
                os.close(slave_fd)
            except OSError:
                pass
        if master_fd is not None:
            try:
                os.close(master_fd)
            except OSError:
                pass
        if temp_dir:
            shutil.rmtree(temp_dir, ignore_errors=True)
        if slot_reserva:
            with PROCESSOS_TERMINAL_LOCK:
                if TERMINAL_POR_USUARIO.get(usuario_id) == sid:
                    TERMINAL_POR_USUARIO.pop(usuario_id, None)
            compilador_seguro.liberar_slot()


@socketio.on("terminal_entrada")
def terminal_entrada(dados):
    sid = request.sid
    dados = dados or {}
    texto = str(dados.get("texto", ""))[:10_000]

    with PROCESSOS_TERMINAL_LOCK:
        proc_data = PROCESSOS_TERMINAL.get(sid)
    if not proc_data:
        return

    tamanho_entrada = len(proc_data["entrada"].encode("utf-8")) + len(texto.encode("utf-8"))
    if tamanho_entrada > compilador_seguro.MAX_ENTRADA_BYTES:
        emit("terminal_saida", {"texto": "\nLimite de entrada do terminal atingido.\n"})
        return

    proc_data["entrada"] += texto

    try:
        os.write(proc_data["fd"], texto.encode("utf-8"))
    except Exception:
        pass


@socketio.on("terminal_cancelar")
def cancelar_terminal():
    encerrar_processo_socket(request.sid)
    emit("terminal_finalizado", {"codigo": -1})


@socketio.on("disconnect")
def desconectar_terminal():
    encerrar_processo_socket(request.sid)


# Importante para Render/Gunicorn: cria o banco ao importar o app.
iniciar_banco()

if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=5000, debug=True, allow_unsafe_werkzeug=True)
